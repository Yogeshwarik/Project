﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Swap
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 10, num2 = 20;
            Console.WriteLine("before swapping");
            Console.WriteLine(num1);
            Console.WriteLine(num2);
            num1 = num1 + num2;
            num2 = num1 - num2;
            num1 = num1 - num2;
            Console.WriteLine("After Swapping");
            Console.WriteLine(num1);
            Console.WriteLine(num2);
            Console.ReadLine();

        }
    }
}
