﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_SortArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
            int i;
            Console.WriteLine("Enter the Size of an array");
            int size = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the array elements");
            for(i=0;i<size;i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());


            }
            
            for(i=0;i<size;i++)
            {
                for(int j=i+1;j<size; j++)
                {
                    if (a[j] < a[i])
                    {
                        int temp = a[i];
                        a[i] = a[j];
                        a[j] = temp;
                    }
                }
            }
              
            Console.WriteLine("Sorted order");
            for (i = 0; i < size; i++)
            {
                Console.WriteLine(a[i]);
            }
            Console.ReadLine();
        }
    }
}
