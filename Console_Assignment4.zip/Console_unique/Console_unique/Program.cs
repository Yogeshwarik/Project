﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_unique
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "AZXC";

            char[] ch = str.ToCharArray();
            bool flag = true;
             for(int i=0;i<ch.Length;i++)
             {
                for(int k=i+1;k<ch.Length;k++)
                {
                    if(ch[i]==ch[k])
                    {
                        flag = false;
                        break;
                    }

                }
            }
             if(flag==true)
            {
                Console.WriteLine("Unique word");
            }
             else
            {
                Console.WriteLine("Not an unique word");
            }
            Console.ReadLine();
        }
    }
}
