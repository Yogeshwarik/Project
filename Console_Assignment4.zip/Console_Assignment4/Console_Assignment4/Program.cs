﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp1 = new Employee(1,"Yogi",22,5000);

            int id = emp1.GetEmployeeID();
            string name = emp1.GetEmployeeName();
            int age = emp1.GetEmployeeAge();
            int salary = emp1.GetSalary();

            Console.WriteLine("Employee ID :" + id);
            Console.WriteLine("Employee Name :" + name);
            Console.WriteLine("EMplyee age :" + age);
            Console.WriteLine("Employee salary :" + salary);

            Console.WriteLine("******HAPPY BIRTHDAY*********");
            emp1.HappyBirthDay();
            age = emp1.GetEmployeeAge();
            Console.WriteLine("EMplyee age :" + age);
            Console.WriteLine("*******INCREMENTEDE SALARY********");
            emp1.GetSalaryIncrement(2000);
            salary = emp1.GetSalary();
            Console.WriteLine("Incremented salrary :" + salary);


            Console.ReadLine();
           


        }
    }
}
