﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {

            /* Customer obj = new Customer("123456789", "ABC", 22);
             Console.WriteLine(obj.PCustomerContactNo);
             Console.WriteLine(obj.PCustomerName);
             Console.WriteLine(obj.PCustomerAge);*/

            Customer_Online obj1 = new Customer_Online
                ("999999999", "ABC", 22, "COD", "Banglor");

            

            Customer_Online obj = obj1 as Customer_Online;//Type casting


            Console.WriteLine(obj.PCustomerContactNo);
            Console.WriteLine(obj.PCustomerName);
            Console.WriteLine(obj.PCustomerAge);
            Console.WriteLine(obj.PPaymentType);
            Console.WriteLine(obj.PDeliveryAddress);

            Console.ReadLine();

        }
    }
}
