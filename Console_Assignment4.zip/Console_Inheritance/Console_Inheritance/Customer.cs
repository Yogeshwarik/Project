﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Customer// Object class
    {
        protected string CustomerContactNo;
        protected string CustomerName;
        protected int CustomerAge;

        public Customer(string CustomerContactNo,string CustomerName,int CustomerAge)
        {
            this.CustomerContactNo = CustomerContactNo;
            this.CustomerName = CustomerName;
            this.CustomerAge = CustomerAge;

            Console.WriteLine("Parent class Object Counstuctor");
        }
        public string PCustomerContactNo
        {
            get
            {
                return this.CustomerContactNo;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PCustomerAge
        {
            get
            {
                return this.CustomerAge;
            }
        }
    }
}
