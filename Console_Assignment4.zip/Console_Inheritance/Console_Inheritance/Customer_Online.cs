﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Inheritance
{
    class Customer_Online : Customer
    {
        private string PaymentType;
        private string DeliveryAddress;

        public Customer_Online(string CustomerContactNo,string CustomerName,
            int CustomerAge,string PaymentType,string DeliveryAddress)
            :base(CustomerContactNo,CustomerName,CustomerAge)
        {
            this.PaymentType = PaymentType;
            this.DeliveryAddress = DeliveryAddress;
            Console.WriteLine("Child Class Object Constuctor");
        }
        public string PPaymentType
        {
            get
            {
                return this.PaymentType;

            }
        }
        public string PDeliveryAddress
        {
            get
            {
                return this.DeliveryAddress;
            }
        }

    }
}
