﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_samllest_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
            int i;
            
            Console.WriteLine("Enter the size of an array");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements of an araay");
            for(i=0;i<size;i++)
            {
                a[i]=Convert.ToInt32(Console.ReadLine());
            }
            int small = a[0];
            

            for(i=0;i<size;i++)
            {
                if(a[i]<small)
                {
                    small= a[i];
                }
            }
            Console.WriteLine("smallest element from an array:" + small);
            Console.ReadLine();
        }

    }
}
