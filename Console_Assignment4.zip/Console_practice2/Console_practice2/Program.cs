﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_practice2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------Object1--------------");

            Account obj1 = new Account(123, "Yogi", 6000);

            int id = obj1.GetAccountID();
            string name = obj1.GetCustomerName();
            int balance = obj1.GetBalance();

            Console.WriteLine("Account ID : " + id);
            Console.WriteLine("Customer Name : " + name);
            Console.WriteLine("Balance : " + balance);

            obj1.deposite(2000);
            balance = obj1.GetBalance();

            Console.WriteLine("Amount depositede succefully");
           

            obj1.withdraw(1000);
            balance = obj1.GetBalance();

            Console.WriteLine("Amont Withdraw is completed");

            Console.WriteLine("------------Object2--------------");

            Account obj2 = new Account(456, "Pooja", 8000);

            id = obj2.GetAccountID();
            name = obj2.GetCustomerName();
            balance = obj2.GetBalance();

            Console.WriteLine("Account ID : " + id);
            Console.WriteLine("Customer Name : " + name);
            Console.WriteLine("Balance : " + balance);

            obj2.deposite(2000);
            balance = obj2.GetBalance();

            Console.WriteLine("Amount depositede succefully");

            obj2.withdraw(1000);
            balance = obj2.GetBalance();

            Console.WriteLine("Amont Withdraw is completed");


            Console.ReadLine();
        }
    }
}
