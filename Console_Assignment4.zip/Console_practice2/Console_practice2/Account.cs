﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_practice2
{
    class Account
    {
        private int AccountID;
        private string CustomerName;
        private int AccountBalance;

        public Account(int AccountID,string CustomerName,int AccountBalance)
        {
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
        }
        public int GetAccountID()
        {
            return this.AccountID;
        }
        public string GetCustomerName()
        {
            return this.CustomerName;
        }
        public int GetBalance()
        {
            return this.AccountBalance;
        }
        public void deposite(int d)
        {
            AccountBalance = AccountBalance + d;
        }
        public void withdraw(int w)
        {
            AccountBalance = AccountBalance - w;
        } 
    }
}
