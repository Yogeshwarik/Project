﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment8
{
    class Order_Overseas : Order
    {
        public Order_Overseas(string CustomerName, int ItemQauntity, double ItemPrice)
            : base(CustomerName, ItemQauntity, ItemPrice)
        {
            Console.Write("Order Overseas Object");
        }

        public override double GetOrderValue()
        {
            double total = ItemQuantity * ItemPrice;
            total = total + (total * 10) / 100;
            return total;
        }
    }
}
