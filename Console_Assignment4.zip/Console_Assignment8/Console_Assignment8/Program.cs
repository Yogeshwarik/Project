﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter The Customer Name:");
            string name = Console.ReadLine();

            Console.WriteLine("Enter The Item Name:");
            string itemname = Console.ReadLine();

            Console.WriteLine("Enter The Item Price");
            int price = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("Enter The Item Quantity:");
            int quantity = Convert.ToInt32(Console.ReadLine());

            Order obj = null;

            Console.WriteLine("Enter The Type of Object");
            string type = Console.ReadLine();

            
            
            if(type=="Order")
            {
                obj = new Order(name,quantity, price);
            }
            else if(type == "Order_Overseas")
            {
                obj = new Order_Overseas(name, quantity, price);
            }
            if (obj != null)
            {
                Console.WriteLine("Order ID:" + obj.POrderId);
                Console.WriteLine("Customer Name:" + obj.PCustomerName);
                Console.WriteLine("Item Quantity:" + obj.PItemQuantity);
                Console.WriteLine("Item Price:" + obj.PItemPrice);

               double total = obj.GetOrderValue();
                Console.WriteLine("Order value:" + total);
            }

            Console.ReadLine();

        }
    }
}
