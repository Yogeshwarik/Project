﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment8
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        protected int ItemQuantity;
        protected double ItemPrice;
        private static int Count = 100;

        public Order(string CustomerName,int ItemQuantity,double ItemPrice)
        {
            this.OrderID = ++Order.Count;
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;

        }
        public int POrderId
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;

            }
           
        }

        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
        }
        public double PItemPrice
        {
            get
            {
                return this.ItemPrice;
            } 
        }
        public virtual double GetOrderValue()
        {
            double total = ItemQuantity * ItemPrice;
               return total;
        }
    }
}
