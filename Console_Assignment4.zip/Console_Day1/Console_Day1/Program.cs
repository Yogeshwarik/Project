﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1
{
    class Program
    {
        
        static void Main(string[] args)
        {
            /*
            string name="Pathfront";
            string city="BGL";
            int salary=30000;

            Console.WriteLine("Employee Name : " + name);
            Console.WriteLine("Employee City : " + city);
            Console.WriteLine("Employee Salary : " + salary);
            */
            /*
            Console.WriteLine("Enter Your Name : ");
            string name = Console.ReadLine();//return string

            Console.WriteLine("Enter Your City :");
            string city = Console.ReadLine();

            Console.WriteLine("Enter Your Age :");
            int age = Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("Your Name :" + name);
            Console.WriteLine("Your City :" + city);
            Console.WriteLine("Your Age :" + age.ToString());
            */
            bool flag = true;
            int count = 0;
            while(flag)
            {
                Console.WriteLine("Enter Your User ID :");
                string userid = Console.ReadLine();
                Console.WriteLine("Enter Your password:");
                string password = Console.ReadLine();

                if (userid == "user1" && password == "password@123")
                {
                    Console.WriteLine("Valid user");
                    flag = false;
                }
                else
                {
                    Console.WriteLine("Invalid User");
                }

                count++;
                if(count==3)
                {
                    flag = false;
                    Console.WriteLine("Limit is over");
                }
            } 
            

            Console.ReadLine();







        }
    }
}
