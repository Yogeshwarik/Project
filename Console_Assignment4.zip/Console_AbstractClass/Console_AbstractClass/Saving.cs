﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractClass
{
    class Saving : Account
    {
        public Saving(string CustomerName,int AccountBalance)
            :base(CustomerName,AccountBalance)
        {
            Console.WriteLine("Saving Object Constructor");
        }

        public override void Deposite(int Amt)
        {
            this.AccountBalance = this.AccountBalance + Amt + 100;

            
        }

        public override void Withdraw(int Amt)
        {
            this.AccountBalance = this.AccountBalance - Amt - 10;
        }
    }
}
