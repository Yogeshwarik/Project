﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractClass
{
    abstract  class Account
    {
        private int AccountID;
        private string CustomerName;
        protected int AccountBalance;
        private static int Count=1000;

        public Account(string CustomerName, int AccountBalance)
        {
            this.AccountID = ++Account.Count;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;

            Console.WriteLine("Account Class Object Constructor");

        }
        public int PAccountID
        {
            get
            {
                return this.AccountID;

            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int GetBalance()
        {
            return this.AccountBalance;

        }
        public void StopPayment(int CheqeNo)
        {
            Console.WriteLine("Payment is stopped ,ref cheqe no:" + CheqeNo);
        }
        public abstract void Deposite(int Amt);
        public abstract void Withdraw(int Amt);

    }
}
