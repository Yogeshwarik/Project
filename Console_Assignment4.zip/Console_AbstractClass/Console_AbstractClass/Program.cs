﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractClass
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Customer Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Account Balance");
            int Balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Amount Type");
            string type = Console.ReadLine();

            Account obj = null;

            if(type== "Saving")
            {
                obj = new Saving(name, Balance);
            }
            else if(type== "Current")
            {
                obj = new Current(name, Balance);
            }

            if (obj != null)
            {
                Console.WriteLine("Account Id:" + obj.PAccountID);
                Console.WriteLine("Customer Name:" + obj.PCustomerName);
                int accbalance = obj.GetBalance();
                Console.WriteLine("Account Balance:" + accbalance);

                Console.WriteLine("-------------DEPOSITE---------------");
                Console.WriteLine("Enter An Amount to Deposite");
                int Amt = Convert.ToInt32(Console.ReadLine());
                obj.Deposite(Amt);
                accbalance = obj.GetBalance();
                Console.WriteLine("New Balance :" + accbalance);

                Console.WriteLine("---------------WITHDRAW-------------");
                Console.WriteLine("Enter An Amoutn to Withdraw");
                Amt = Convert.ToInt32(Console.ReadLine());
                obj.Withdraw(Amt);
                accbalance = obj.GetBalance();
                Console.WriteLine("New Balance: " + accbalance);

                obj.StopPayment(1001);

            }

                Console.ReadLine();
            }
        }
    }

