﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_GenericAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Company comp = new Company("IBM", "Banglore");
            Console.WriteLine("Company Name:" + comp.PCompanyName);
            Console.WriteLine("Company Address:" + comp.PCompanyAddress);

            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1.Add ,2.Search, 3.Remove, 4.Show,5.Request to Leave,6.Exit");
                Console.WriteLine("Enter Your Choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter the Employee Name");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter the Employee city");
                            string city = Console.ReadLine();
                            Employee e = new Employee(name, city);


                            comp.AddEmployee(e);

                            Console.WriteLine("Employee Added  is" + e.PEmloyeeID);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());

                            comp.SearchEmployee(id);
                            Employee e = comp.SearchEmployee(id)
;
                            if(e!=null)
                            {
                                Console.WriteLine("Employee ID:" + e.PEmloyeeID);
                                Console.WriteLine("Employee Name:" + e.PEmployeeName);
                                Console.WriteLine("Employee City:" + e.PEmployeeCity);
                            }
                            else
                            {
                                Console.WriteLine("Employee Not Found");
                            }
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            
                            bool status=comp.RemoveEmployee(id);
                            if(status==true)
                            {
                                Console.WriteLine("remove succefully");

                            }
                            else
                            {
                                Console.WriteLine("not found");
                            }


                            break;
                        }
                    case 4:
                        {
                            comp.ShowEmployee();
                            break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter the Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());

                            Employee e = comp.SearchEmployee(id);
                            Console.WriteLine("Enter the Reasons to leave");
                            string reason = Console.ReadLine();
                            e.RequestLeave(reason);

                           
                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;
                        }
                }
            }

        }
    }
}
