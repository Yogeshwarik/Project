﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_GenericAssignment
{
    class Employee
    {
        private int EmployeeID;
        private string EmployeeName;
        private string EmployeeCity;
        private static int Count = 100;

        public delegate void dellleave(int employeeid, string msg);
        public event dellleave evtleave;


        public Employee(string EmployeeName,string EmployeeCity)
        {
            this.EmployeeID = ++Employee.Count;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;

        }
        public int PEmloyeeID
        {
            get
            {
                return this.EmployeeID;
            }
        }
        public string PEmployeeName
        {
            get
            {
                return this.EmployeeName;
            }
        }
        public string PEmployeeCity
        {
            get
            {
                return this.EmployeeCity;
            }
        }
        public void RequestLeave(string Leavreason)
        {
            Console.WriteLine("Emplyee request to leave:" + Leavreason);
            if(this.evtleave!=null)
            {
                this.evtleave(this.EmployeeID, Leavreason);
            }

        }
    }
}
