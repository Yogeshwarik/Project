﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment9
{
    class HomeLoan : Loan
    {
        public HomeLoan(string CustomerName, string CustomerEmailID, string CustomerMobileNo, int LoanAmount,
            int Duration, int Rate) : base(CustomerName, CustomerEmailID, CustomerMobileNo,LoanAmount, Duration, Rate)
        {
            Console.WriteLine("Home Loan object");
        }

        public override int  PayEMI(int Amount)
        {
            total = LoanAmount / Duration + Amount;
            return total;
        }
    
    } 
}
