﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment9
{
    abstract class Loan
    {
        protected int LoanID;
        protected string CustomerName;
        protected string CustomerEmailID;
        protected  string CustomerMobileNo;
        protected int LoanAmount;
        protected int Duration;
        protected int Rate;
        protected int total;

        private static int Count = 1000;

        public Loan(string CustomerName,string CustomerEmailID,string CustomerMobileNo,int LoanAmount,
            int Duration,int Rate)
        {
            this.LoanID = ++Loan.Count;
            this.CustomerName = CustomerName;
            this.CustomerEmailID = CustomerEmailID;
            this.CustomerMobileNo = CustomerMobileNo;
            this.LoanAmount = LoanAmount;
            this.Duration = Duration;
            this.Rate = Rate;
        }

        public Loan(string customerName, string customerEmailID, string customerMobileNo, int duration, int rate)
        {
            CustomerName = customerName;
            CustomerEmailID = customerEmailID;
            CustomerMobileNo = customerMobileNo;
            Duration = duration;
            Rate = rate;
        }

        public int PLoanID
        {
            get
            {
                return this.LoanID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PCustomerEmailID
        {
            get
            {
                return this.CustomerEmailID;
            }
        }
        public string PCustomerMobileNo
        {
            get
            {
                return this.CustomerMobileNo;
            }
        }
        public int PLoanAmount
        {
            get
            {
                return this.LoanAmount;
            }
        }

        

        public int PDuration
        {
            get
            {
                return this.Duration;
            }
        }
        public int PRate
        {
            get
            {
                return this.Rate;
            }
        }
        public int GetPendingLoan()
        {
            int pending=LoanAmount-total;
            return pending;
        }
        public abstract int PayEMI(int Amount);
       
    }
}
