﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment9
{
    class VehicalLoan : Loan
    {
        public VehicalLoan(string CustomerName, string CustomerEmailID, string CustomerMobileNo, int LoanAmount,
            int Duration, int Rate) : base(CustomerName, CustomerEmailID, CustomerMobileNo, LoanAmount, Duration, Rate)
        {
            Console.WriteLine("Vehical Loan Object");
        }

        public override int PayEMI(int Amount)
        {
            total = LoanAmount / Duration + Amount * (Rate / 100);
            return total;
        }
    }
}
