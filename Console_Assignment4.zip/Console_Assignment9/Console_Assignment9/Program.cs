﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment9
{
    class Program
    {
        private static object Amount;

        static void Main(string[] args)
        {
            Console.WriteLine("enter the Customer Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter the Email ID");
            string email = Console.ReadLine();

            Console.WriteLine("Enter the Mobile");
            string mobile = Console.ReadLine();

            Console.WriteLine("Enter the Loan Amount");
            int amount = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("entert the duration");
            int d = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Rate");
            int r = Convert.ToInt32(Console.ReadLine());

            Loan obj = null;

            Console.WriteLine("Enter the type of object");
            string type = Console.ReadLine();

            if(type== "HomeLoan")
            {
                obj = new HomeLoan(name, email, mobile, amount, d, r);
            }
            else if(type== "VehicalLoan")
            {
                obj = new VehicalLoan(name, email, mobile, amount, d, r);
            }
            if(obj!=null)
            {
                Console.WriteLine("Loan ID:" + obj.PLoanID);
                Console.WriteLine("Customer Name:" + obj.PCustomerName);
                Console.WriteLine("Email ID:" + obj.PCustomerEmailID);
                Console.WriteLine("Mobile No:" + obj.PCustomerMobileNo);
                Console.WriteLine("Loan Amount:" + obj.PLoanAmount);
                Console.WriteLine("Duaration:" + obj.PDuration);
                Console.WriteLine("Rate:" + obj.PRate);
                Console.WriteLine("Enter the Principle Amount");
                int amt = Convert.ToInt32(Console.ReadLine());

                int emi = obj.PayEMI(amt);
                Console.WriteLine("monthly EMI is:" + emi);
                amt = obj.GetPendingLoan();
                Console.WriteLine("the pending Amount is:" + amt);

                Console.ReadLine();
            }


            
        }
    }
}
