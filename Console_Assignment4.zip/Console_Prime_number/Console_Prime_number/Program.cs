﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Prime_number
{
    class Program
    {
        static void Main(string[] args)
        {
            int count = 0;
            Console.WriteLine("Enter the number");
            int n = Convert.ToInt32(Console.ReadLine());
            for(int i=1;i<=n;i++)
            {
                if(n%i==0)
                {
                    count++;
                }
              
            }
            if(count==2)
            {
                Console.WriteLine("Number is prime");
            
            }
            else
            {
                Console.WriteLine("Number is not a prime");
            }
            Console.ReadLine();
        }
    }
}
