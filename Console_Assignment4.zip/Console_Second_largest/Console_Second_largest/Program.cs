﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Second_largest
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a= new int[10];
            int i;
            Console.WriteLine("Enter the size of an array");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements of an array");
            for(i=0;i<size;i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }
            int large = a[0];
            int slarge =a[1];
            for(i=0;i<size;i++)
            {
                if(a[i]>large)
                {
                    large = a[i];
                }
                else if(a[i]>slarge)
                {
                    slarge = a[i];
                }
            }
            Console.WriteLine("Second largest:" + slarge);
            Console.ReadLine();
        }
    }
}
