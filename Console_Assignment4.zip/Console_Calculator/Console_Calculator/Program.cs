﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Calculator
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Number 1");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the Number 2");
            int num2 = Convert.ToInt32(Console.ReadLine());

            ClassLibrary_Calculator.Calculator cal = new ClassLibrary_Calculator.Calculator();

            int result = cal.GetSum(num1,num2);
            Console.WriteLine("Sum:" + result);

            result = cal.GetMultiply(num1, num2);
            Console.WriteLine("Multiply:" + result);

            result = cal.GetSubtract(num1, num2);
            Console.WriteLine("Subtract:" + result);

            result = cal.GetDivide(num1, num2);
            Console.WriteLine("Divide:" + result);

            Console.ReadLine();

        }
    }
}
