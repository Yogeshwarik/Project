﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_String
{
    class Program
    {
        static void Main(string[] args)
        {

            string str = "hellz";
            // string s = str.Substring(1,2);//ell

            //Console.WriteLine(s);


            char[] ch = str.ToCharArray();
            for(int i=0;i<ch.Length;i++)
            {

                int no = Convert.ToInt32(ch[i]);
                int max = Convert.ToChar('z');
                if (no == max)
                {
                    no = Convert.ToChar('b');
                }
                else
                {
                    no+=2;
                }
                ch[i] = Convert.ToChar(no);
             
                //Console.WriteLine(ch[i]);
            }
            string newstr = new string(ch);
            Console.WriteLine(newstr);


            /*
            string str = "abc";
            char[] ch = { 'a', 'b', 'c' };

            object obj =new string(ch);//creates new object of string(not in pool)
            if(str==obj)
            {
                Console.WriteLine("true");
            
            }
            else
            {
                Console.WriteLine("false");

            }
            if(str.Equals(obj))
            {
                Console.WriteLine("Content is same");
            }
            else
            {
                Console.WriteLine("Content is different");
            }*/
            Console.ReadLine();
        }
    }
}
