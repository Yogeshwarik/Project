﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Params
{
    class Test3
    {
        public void Call(params int []marks)
        {
            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }
        }
    }
}
