﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Params
{
    class Test
    {
        //Auto genarate
        public int StudentID { get; } = 1;//_StudentID=1,readOnly
        public string StudentName { get; set; }//_StudentName
        private static int Count = 1000;
        public Test(string StudentName)
        {
            this.StudentID = ++Test.Count;
            this.StudentName = StudentName;
        }
    }
}
