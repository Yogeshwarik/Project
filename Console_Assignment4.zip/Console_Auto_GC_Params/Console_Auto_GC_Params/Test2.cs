﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Params
{
    class Test2
    {
        public int ID { get; }
        public string name { get; set; }
        private static int Count = 1000;
        public Test2()
        {
            Console.WriteLine("Constructor called...");
            this.ID = ++Test2.Count;
        }
        ~Test2()
        {
            Console.WriteLine("Destructor Called...");//Finalize Function
        }
    }
}
