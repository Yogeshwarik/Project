﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Auto_GC_Params
{
    class Program
    {
        static void Main(string[] args)
        {

           // int[] array = { 10, 20, 40, 55, 11 };

            Test3 obj = new Test3();
            

              obj.Call(11,33,22,44,55);

            /*int i=0;
            while (i < 10)
          {
                Test2 obj = new Test2();
                GC.SuppressFinalize(obj);
                //obj = null;
                i++;

            }
            GC.Collect();*/
            Console.ReadLine();

        }      
    }
}
