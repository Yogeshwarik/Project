﻿namespace win_customer
{
    partial class frm_newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_customerpassword = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_mobileno = new System.Windows.Forms.Label();
            this.lbl_emailid = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_customerpassword = new System.Windows.Forms.TextBox();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.lbl_loginstatus = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(96, 33);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(178, 25);
            this.lbl_customername.TabIndex = 0;
            this.lbl_customername.Text = "Customer Name :";
            // 
            // lbl_customerpassword
            // 
            this.lbl_customerpassword.AutoSize = true;
            this.lbl_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerpassword.Location = new System.Drawing.Point(96, 82);
            this.lbl_customerpassword.Name = "lbl_customerpassword";
            this.lbl_customerpassword.Size = new System.Drawing.Size(216, 25);
            this.lbl_customerpassword.TabIndex = 1;
            this.lbl_customerpassword.Text = "Customer Password :";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(96, 140);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(159, 25);
            this.lbl_city.TabIndex = 2;
            this.lbl_city.Text = "Customer City :";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(96, 191);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(201, 25);
            this.lbl_address.TabIndex = 3;
            this.lbl_address.Text = "Customer Address :";
            // 
            // lbl_mobileno
            // 
            this.lbl_mobileno.AutoSize = true;
            this.lbl_mobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mobileno.Location = new System.Drawing.Point(96, 249);
            this.lbl_mobileno.Name = "lbl_mobileno";
            this.lbl_mobileno.Size = new System.Drawing.Size(210, 25);
            this.lbl_mobileno.TabIndex = 4;
            this.lbl_mobileno.Text = "Customer Mobileno :";
            // 
            // lbl_emailid
            // 
            this.lbl_emailid.AutoSize = true;
            this.lbl_emailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emailid.Location = new System.Drawing.Point(96, 316);
            this.lbl_emailid.Name = "lbl_emailid";
            this.lbl_emailid.Size = new System.Drawing.Size(195, 25);
            this.lbl_emailid.TabIndex = 5;
            this.lbl_emailid.Text = "Customer EmailID :";
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(331, 33);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(209, 31);
            this.txt_customername.TabIndex = 6;
            // 
            // txt_customerpassword
            // 
            this.txt_customerpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerpassword.Location = new System.Drawing.Point(331, 82);
            this.txt_customerpassword.Name = "txt_customerpassword";
            this.txt_customerpassword.Size = new System.Drawing.Size(209, 31);
            this.txt_customerpassword.TabIndex = 7;
            // 
            // ddl_cities
            // 
            this.ddl_cities.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(331, 140);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(209, 33);
            this.ddl_cities.TabIndex = 8;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeraddress.Location = new System.Drawing.Point(331, 200);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(209, 31);
            this.txt_customeraddress.TabIndex = 9;
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(331, 249);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(209, 31);
            this.txt_customermobileno.TabIndex = 10;
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremailid.Location = new System.Drawing.Point(331, 313);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(209, 31);
            this.txt_customeremailid.TabIndex = 11;
            // 
            // btn_newuser
            // 
            this.btn_newuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newuser.Location = new System.Drawing.Point(92, 379);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(249, 36);
            this.btn_newuser.TabIndex = 12;
            this.btn_newuser.Text = "New User";
            this.btn_newuser.UseVisualStyleBackColor = true;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            // 
            // lbl_loginstatus
            // 
            this.lbl_loginstatus.AutoSize = true;
            this.lbl_loginstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_loginstatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_loginstatus.Location = new System.Drawing.Point(117, 445);
            this.lbl_loginstatus.Name = "lbl_loginstatus";
            this.lbl_loginstatus.Size = new System.Drawing.Size(142, 25);
            this.lbl_loginstatus.TabIndex = 13;
            this.lbl_loginstatus.Text = "Customer ID :";
            // 
            // frm_newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 516);
            this.Controls.Add(this.lbl_loginstatus);
            this.Controls.Add(this.btn_newuser);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.txt_customerpassword);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_emailid);
            this.Controls.Add(this.lbl_mobileno);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_customerpassword);
            this.Controls.Add(this.lbl_customername);
            this.Name = "frm_newuser";
            this.Text = "frm_newuser";
            this.Load += new System.EventHandler(this.frm_newuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_customerpassword;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_mobileno;
        private System.Windows.Forms.Label lbl_emailid;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_customerpassword;
        private System.Windows.Forms.ComboBox ddl_cities;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.Label lbl_loginstatus;
    }
}