﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;


namespace win_customer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter Login ID";
            }
            else if (txt_password.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter Password";
            }
            else
            {
                try
                {

                    int loginid = Convert.ToInt32(txt_loginid.Text);
                    string password = txt_password.Text;
                    CustomerDAL dal = new CustomerDAL();
                    MessageBox.Show("Four");
                    bool status = dal.Login(loginid, password);
                    MessageBox.Show("Five");
                if (status == true)
                    {
                        frm_home obj = new frm_home();
                        obj.Show();


                    }
                    else
                    {
                        lbl_loginstatus.Text = "Invalid User ID or password";
                    }
                }
                catch(System.Data.SqlClient.SqlException exp)
                {
                    MessageBox.Show("Data Base error ,contact Admin");
                }
                catch(Exception exp)
                {
                    MessageBox.Show("Someother error");
                    //MessageBox.Show(exp.Message);
                }

            }
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            frm_newuser obj = new frm_newuser();
            obj.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }
    }
}
