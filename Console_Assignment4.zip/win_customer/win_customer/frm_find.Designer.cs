﻿namespace win_customer
{
    partial class frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_customeremailid = new System.Windows.Forms.TextBox();
            this.txt_customermobileno = new System.Windows.Forms.TextBox();
            this.txt_customeraddress = new System.Windows.Forms.TextBox();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.lbl_emailid = new System.Windows.Forms.Label();
            this.lbl_mobileno = new System.Windows.Forms.Label();
            this.lbl_address = new System.Windows.Forms.Label();
            this.lbl_city = new System.Windows.Forms.Label();
            this.lbl_customername = new System.Windows.Forms.Label();
            this.btn_find = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.lbl_delete = new System.Windows.Forms.Button();
            this.lbl_customerid = new System.Windows.Forms.Label();
            this.txt_customerid = new System.Windows.Forms.TextBox();
            this.lbl_status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_customeremailid
            // 
            this.txt_customeremailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeremailid.Location = new System.Drawing.Point(342, 333);
            this.txt_customeremailid.Name = "txt_customeremailid";
            this.txt_customeremailid.Size = new System.Drawing.Size(209, 31);
            this.txt_customeremailid.TabIndex = 23;
            // 
            // txt_customermobileno
            // 
            this.txt_customermobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customermobileno.Location = new System.Drawing.Point(342, 279);
            this.txt_customermobileno.Name = "txt_customermobileno";
            this.txt_customermobileno.Size = new System.Drawing.Size(209, 31);
            this.txt_customermobileno.TabIndex = 22;
            // 
            // txt_customeraddress
            // 
            this.txt_customeraddress.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customeraddress.Location = new System.Drawing.Point(342, 224);
            this.txt_customeraddress.Name = "txt_customeraddress";
            this.txt_customeraddress.Size = new System.Drawing.Size(209, 31);
            this.txt_customeraddress.TabIndex = 21;
            // 
            // ddl_cities
            // 
            this.ddl_cities.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(342, 152);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(209, 33);
            this.ddl_cities.TabIndex = 20;
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(342, 72);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(209, 31);
            this.txt_customername.TabIndex = 18;
            // 
            // lbl_emailid
            // 
            this.lbl_emailid.AutoSize = true;
            this.lbl_emailid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_emailid.Location = new System.Drawing.Point(72, 339);
            this.lbl_emailid.Name = "lbl_emailid";
            this.lbl_emailid.Size = new System.Drawing.Size(195, 25);
            this.lbl_emailid.TabIndex = 17;
            this.lbl_emailid.Text = "Customer EmailID :";
            // 
            // lbl_mobileno
            // 
            this.lbl_mobileno.AutoSize = true;
            this.lbl_mobileno.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mobileno.Location = new System.Drawing.Point(72, 282);
            this.lbl_mobileno.Name = "lbl_mobileno";
            this.lbl_mobileno.Size = new System.Drawing.Size(210, 25);
            this.lbl_mobileno.TabIndex = 16;
            this.lbl_mobileno.Text = "Customer Mobileno :";
            // 
            // lbl_address
            // 
            this.lbl_address.AutoSize = true;
            this.lbl_address.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_address.Location = new System.Drawing.Point(72, 227);
            this.lbl_address.Name = "lbl_address";
            this.lbl_address.Size = new System.Drawing.Size(201, 25);
            this.lbl_address.TabIndex = 15;
            this.lbl_address.Text = "Customer Address :";
            // 
            // lbl_city
            // 
            this.lbl_city.AutoSize = true;
            this.lbl_city.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_city.Location = new System.Drawing.Point(72, 152);
            this.lbl_city.Name = "lbl_city";
            this.lbl_city.Size = new System.Drawing.Size(159, 25);
            this.lbl_city.TabIndex = 14;
            this.lbl_city.Text = "Customer City :";
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(72, 75);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(178, 25);
            this.lbl_customername.TabIndex = 12;
            this.lbl_customername.Text = "Customer Name :";
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(592, 17);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(172, 43);
            this.btn_find.TabIndex = 24;
            this.btn_find.Text = "Find Customer";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(126, 404);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(156, 50);
            this.btn_update.TabIndex = 25;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // lbl_delete
            // 
            this.lbl_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_delete.Location = new System.Drawing.Point(342, 404);
            this.lbl_delete.Name = "lbl_delete";
            this.lbl_delete.Size = new System.Drawing.Size(247, 50);
            this.lbl_delete.TabIndex = 26;
            this.lbl_delete.Text = "Delete Customer";
            this.lbl_delete.UseVisualStyleBackColor = true;
            this.lbl_delete.Click += new System.EventHandler(this.lbl_delete_Click);
            // 
            // lbl_customerid
            // 
            this.lbl_customerid.AutoSize = true;
            this.lbl_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customerid.Location = new System.Drawing.Point(72, 17);
            this.lbl_customerid.Name = "lbl_customerid";
            this.lbl_customerid.Size = new System.Drawing.Size(142, 25);
            this.lbl_customerid.TabIndex = 27;
            this.lbl_customerid.Text = "Customer ID :";
            // 
            // txt_customerid
            // 
            this.txt_customerid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customerid.Location = new System.Drawing.Point(342, 13);
            this.txt_customerid.Name = "txt_customerid";
            this.txt_customerid.Size = new System.Drawing.Size(209, 31);
            this.txt_customerid.TabIndex = 28;
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_status.ForeColor = System.Drawing.Color.Red;
            this.lbl_status.Location = new System.Drawing.Point(96, 489);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(171, 25);
            this.lbl_status.TabIndex = 29;
            this.lbl_status.Text = "Customer Status";
            // 
            // frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 531);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.txt_customerid);
            this.Controls.Add(this.lbl_customerid);
            this.Controls.Add(this.lbl_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_customeremailid);
            this.Controls.Add(this.txt_customermobileno);
            this.Controls.Add(this.txt_customeraddress);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_emailid);
            this.Controls.Add(this.lbl_mobileno);
            this.Controls.Add(this.lbl_address);
            this.Controls.Add(this.lbl_city);
            this.Controls.Add(this.lbl_customername);
            this.Name = "frm_find";
            this.Text = "frm_find";
            this.Load += new System.EventHandler(this.frm_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_customeremailid;
        private System.Windows.Forms.TextBox txt_customermobileno;
        private System.Windows.Forms.TextBox txt_customeraddress;
        private System.Windows.Forms.ComboBox ddl_cities;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.Label lbl_emailid;
        private System.Windows.Forms.Label lbl_mobileno;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Label lbl_city;
        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button lbl_delete;
        private System.Windows.Forms.Label lbl_customerid;
        private System.Windows.Forms.TextBox txt_customerid;
        private System.Windows.Forms.Label lbl_status;
    }
}