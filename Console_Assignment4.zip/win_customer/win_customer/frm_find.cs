﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_customer
{
    public partial class frm_find : Form
    {
        public frm_find()
        {
            InitializeComponent();
        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_customerid.Text == string.Empty)
            {
                lbl_status.Text = "enter the employee ID";
            }
            else
            {
                int id = Convert.ToInt32(txt_customerid.Text);
              
                CustomerDAL dal = new CustomerDAL();
                CustomerModel model = dal.Find(id);
                if (model != null)
                {
                  
                   txt_customername.Text = model.CustomerName;
                    ddl_cities.Text = model.CustomerCity;

                   txt_customeraddress.Text = model.CustomerAddress;
                    txt_customermobileno.Text = model.CustomerMobileno;
                    txt_customeremailid.Text = model.CustomerEmailID;
                }
                else
                {
                    lbl_status.Text = "Customer not found";
                }
            }
        }

        private void frm_find_Load(object sender, EventArgs e)
        {
            ddl_cities.Items.Add("Tumkur");
            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("Pune");
            ddl_cities.Items.Add("Chennai");
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            
                int id = Convert.ToInt32(txt_customerid.Text);
                string address = txt_customeraddress.Text;
                string mobileno = txt_customermobileno.Text;
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.UpdateCustomer(id, address,mobileno);
                if (status == true)
                {
                    lbl_status.Text = "customer update";
                }
                else
                {
                    lbl_status.Text = "not found";
                }
            }

        private void lbl_delete_Click(object sender, EventArgs e)
        {
            
                int id = Convert.ToInt32(txt_customerid.Text);
                CustomerDAL dal = new CustomerDAL();
                bool status = dal.DeleteCustomer(id);
                if (status == true)
                {
                    lbl_status.Text = "Deleted";
                }
                else
                {
                    lbl_status.Text = "not deleted";
                }
            }
        
    }
    
}
