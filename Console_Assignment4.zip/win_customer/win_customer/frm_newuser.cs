﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_customer
{
    public partial class frm_newuser : Form
    {
        public frm_newuser()
        {
            InitializeComponent();
        }

        private void frm_newuser_Load(object sender, EventArgs e)
        {
            ddl_cities.Items.Add("Tumkur");
            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("Pune");
            ddl_cities.Items.Add("Chennai");

        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter Customer Name";

            }
            else if (txt_customerpassword.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter Customer Password";
            }
            else if (ddl_cities.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Select City";
            }
            else if (txt_customeraddress.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter The Address";
            }
            else if (txt_customermobileno.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter The Mobile number";
            }
            else if (txt_customeremailid.Text == string.Empty) 
            {
                lbl_loginstatus.Text = "Enter the Email ID";
            }
            else
            {
                CustomerModel model = new CustomerModel();
                model.CustomerName= txt_customername.Text;
                model.CustomerPassword= txt_customerpassword.Text;
                model.CustomerCity = ddl_cities.Text;
                model.CustomerAddress = txt_customeraddress.Text;
                model.CustomerMobileno = txt_customermobileno.Text;
                model.CustomerEmailID = txt_customeremailid.Text;
                CustomerDAL dal = new CustomerDAL();
                int id = dal.AddCustomer(model);
                lbl_loginstatus.Text = "Customer Added,ID:" + id;
            }
        }
    }
}
