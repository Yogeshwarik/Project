﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace win_customer
{
    class CustomerDAL
    {
        SqlConnection con = new SqlConnection
          (ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddCustomer(CustomerModel model)
        {
            try
            {
                SqlCommand com_addcustomer = new SqlCommand("proc_addcustomer", con);
                com_addcustomer.CommandType = CommandType.StoredProcedure;
                com_addcustomer.Parameters.AddWithValue("@name", model.CustomerName);
                com_addcustomer.Parameters.AddWithValue("@pwd", model.CustomerPassword);
                com_addcustomer.Parameters.AddWithValue("@city", model.CustomerCity);
                com_addcustomer.Parameters.AddWithValue("@address", model.CustomerAddress);
                com_addcustomer.Parameters.AddWithValue("@mobileno", model.CustomerMobileno);
                com_addcustomer.Parameters.AddWithValue("@emailid", model.CustomerEmailID);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_addcustomer.Parameters.Add(para_return);
                con.Open();
                
                com_addcustomer.ExecuteNonQuery();
                
                con.Close();
                int id = Convert.ToInt32(para_return.Value);
                return id;
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool Login(int id ,string password)
        {
            try
            {
                SqlCommand com_login = new SqlCommand("proc_login", con);
                com_login.CommandType = CommandType.StoredProcedure;
                com_login.Parameters.AddWithValue("@id", id);
                com_login.Parameters.AddWithValue("@pwd ", password);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_login.Parameters.Add(para_return);
                con.Open();
                System.Windows.Forms.MessageBox.Show("one");
                com_login.ExecuteNonQuery();
                System.Windows.Forms.MessageBox.Show("two");
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            finally
            {
                System.Windows.Forms.MessageBox.Show("three");
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public bool UpdateCustomer(int id, string address, string mobileno)
        {
            try
            {
                SqlCommand com_update_customer = new SqlCommand("proc_updatecustomer", con);
                com_update_customer.CommandType = CommandType.StoredProcedure;
                com_update_customer.Parameters.AddWithValue("@id", id);
                com_update_customer.Parameters.AddWithValue("@address", address);
                com_update_customer.Parameters.AddWithValue("@mobileno", mobileno);
                SqlParameter para_return = new SqlParameter();
                para_return.Direction = ParameterDirection.ReturnValue;
                com_update_customer.Parameters.Add(para_return);
                con.Open();
                com_update_customer.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if (count > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        
        public bool DeleteCustomer(int id)

        {
            try
            {
                SqlCommand com_delete = new SqlCommand("proc_deletecustomer", con);
                com_delete.CommandType = CommandType.StoredProcedure;
                com_delete.Parameters.AddWithValue("@id", id);
                SqlParameter para_return = new SqlParameter(); 
                para_return.Direction = ParameterDirection.ReturnValue;
                com_delete.Parameters.Add(para_return);
                con.Open();
                com_delete.ExecuteNonQuery();
                con.Close();
                int count = Convert.ToInt32(para_return.Value);
                if(count>0)
                {
                    return true;
                }
                else
                {
                    return false;
                }


            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public CustomerModel Find(int id)
        {
            try
            {
                SqlCommand com_find = new SqlCommand("proc_findcustomer", con);
                com_find.CommandType = CommandType.StoredProcedure;
                com_find.Parameters.AddWithValue("@id", id);
                SqlParameter para_return = new SqlParameter();
                con.Open();
                SqlDataReader dr = com_find.ExecuteReader();
                if(dr.Read())
                {
                    CustomerModel model = new CustomerModel();
                    model.CustomerID = dr.GetInt32(0);
                    model.CustomerName = dr.GetString(1);
                    model.CustomerPassword = dr.GetString(2);
                    model.CustomerCity = dr.GetString(3);
                    model.CustomerAddress = dr.GetString(4);
                    model.CustomerMobileno = dr.GetString(5);
                    model.CustomerEmailID = dr.GetString(6);
                    con.Close();
                    return model;

                }
                return null;

            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        public List<CustomerModel> Search(string key)
        {
            try
            { 
            SqlCommand com_search = new SqlCommand("proc_searchcustomer", con);
            com_search.CommandType = CommandType.StoredProcedure;
            com_search.Parameters.AddWithValue("@key", key);
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<CustomerModel> customerlist = new List<CustomerModel>();
            while (dr.Read())
            {
                CustomerModel model = new CustomerModel();
                model.CustomerID = dr.GetInt32(0);
                model.CustomerName = dr.GetString(1);
                model.CustomerPassword = dr.GetString(2);
                model.CustomerCity = dr.GetString(3);
                model.CustomerAddress = dr.GetString(4);
                model.CustomerMobileno = dr.GetString(5);
                model.CustomerEmailID = dr.GetString(6);
                customerlist.Add(model);
            }
            con.Close();
            return customerlist;

        }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
        }
        
            
    }
    
}
