﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Functions_Access_Modifiers_Satatic
{
   partial class XYZ
    {
        public void Call3()
        {

        }
        public void Call4()
        {

        }
    }
}
