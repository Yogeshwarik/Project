﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Functions_Access_Modifiers_Satatic
{
    class Test_Static
    {
        static Test_Static()
        {
            Console.WriteLine("This is the static constuctor");
            Test_Static.count = 10;
        }
        public Test_Static()
        {
            Test_Static.count = 10;
        }
        public static int count;//Defaul 0;
        public static void Call()
        {
            Console.WriteLine("It is Static function");
        }
    }
}
