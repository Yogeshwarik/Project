﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Functions_Access_Modifiers_Satatic
{
    class Program
    {
        static void Main(string[] args)
        {

            Test_Static.count = Test_Static.count+10;

            Console.WriteLine(Test_Static.count);

            Test_Static.count = 30;
            Test_Static o = new Test_Static();
            Console.WriteLine(Test_Static.count);
           
            Test_Static.Call();









           
            /*Test obj = new Test();
            int i = 100;
            //obj.Call1(i);//call by value;
            //obj.Call2(ref i);
            obj.Call3(out i);//call by Out
            Console.WriteLine(i);*/




            /*int n1 = 100;
            int n2 = 200;
            double d1 = 10.2;
            double d2 = 30.4;

            int x = Convert.ToInt32(null);//0
            int x2 = int.Parse(null);//runtime error,only string to integer



            Calc obj = new Calc();
            int r1 = obj.AddNumbers(n1, n2);
            int r2 = obj.AddNumbers(n1, n2, 300);
            double r3 = obj.AddNumbers(d1, d2);
            double r4 = obj.AddNumbers(n1, d1);
            double r5=obj.AddNumbers(d1,n1);
            Console.WriteLine(r1);
            Console.WriteLine(r2);
            Console.WriteLine(r3);
            Console.WriteLine(r4);
            Console.WriteLine(r5);*/




            Console.ReadLine();
        }
    }
}
