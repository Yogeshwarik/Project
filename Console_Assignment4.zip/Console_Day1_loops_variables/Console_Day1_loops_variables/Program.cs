﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Day1_loops_variables
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            int count = 100;
            Console.WriteLine(count.ToString());

            const int x = 100;
            Console.WriteLine(x.ToString());

            //x = 200;//error
            */
            /*
            int count = 100;
            while(count<10)
            {
                Console.WriteLine(count.ToString());
                count++;

            }*/
            /*
            for(int c=0;c<10;c++)
            {
                Console.WriteLine();
            }*/
            /*
            int[] marks = new int[5];
            marks[0] = 56;
            marks[1] = 66;
            marks[2] = 55;
            marks[3] = 77;
            marks[4] = 88;

            foreach(int m in marks)
            {
                Console.WriteLine(m.ToString());
            }

            int sum = 0;
            for(int c=0;c<marks.Length;c++)
            {
                sum = sum + marks[c];
                Console.WriteLine(marks[c]);
            }
            Console.WriteLine("sum:" + sum.ToString());

            Console.WriteLine(marks[0].ToString());

            int size = marks.Length;
            Console.WriteLine(size.ToString());

            int[] marks1 = { 30, 44, 22, 55 };

            int size1 = marks1.Length;

            Console.WriteLine(size1.ToString());
            */

            /*
            Console.WriteLine("Entre Your Option");

            int opt = Convert.ToInt32(Console.ReadLine());
            switch(opt)
            {
                case 1:
                    {
                        Console.WriteLine("Case 1");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Case 2");
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Default");
                        break;

                    }

            }
            */
            int[] marks = { 20, 40, 25, 66, 21 };

            int temp = marks[0];
            marks[0] = marks[marks.Length - 1];
            marks[marks.Length - 1] = temp;
            for(int c=0;c<marks.Length;c++)
            {
                Console.WriteLine("swapping numbers" +marks[c]);
            }
         
            int max = marks[0];
            int min = marks[1];
            //int temp=0;
            for (int c=1;c<marks.Length;c++)
            {
                if(marks[c]>max)
                {
                    max = marks[c];
                }
                if(marks[c]<min)
                {
                    min = marks[c];
                }
               

                
            }
            

            Console.WriteLine("Max:" + max);
            Console.WriteLine("min:" + min);
          


            Console.ReadLine();
        }
    }
}
