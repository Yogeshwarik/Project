﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number 1");
            int num1 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the number 2");
            int num2 = Convert.ToInt32(Console.ReadLine());

            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1.Add,2.Subtract,3.Divide,4.Multiple,5.exit,6.Reset");
                Console.WriteLine("Enter your choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1:
                        {
                            int total = num1 + num2;
                            //int total = Convert.ToInt32(Console.ReadLine());

                            Console.WriteLine("Sum of two numbers :"+total.ToString());
                           
                            break;
                        }
                    case 2:
                        {
                            int sub = num1 - num2;
                            Console.WriteLine("Subtracting : " + sub.ToString());
                            break;
                        }
                    case 3:
                        {
                            int div = num1 / num2;
                            Console.WriteLine("divide :" + div.ToString());
                            break;
                        }
                    case 4:
                        {
                            int mul = num1 * num2;
                            Console.WriteLine("Multiplication:" + mul.ToString());
                            break;
                        }
                    case 5:
                        {
                            flag = false;
                            break;
                        }
                    case 6:
                        {
                            Console.WriteLine("Enter the number1");
                            num1 = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("Enter the number2");
                            num2 = Convert.ToInt32(Console.ReadLine());
                            break;
                        }
                }
            }

        }
    }
}
