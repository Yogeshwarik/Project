Create database db_mvc

Create table tbl_students
(
StudentID int identity(1000,1) primary key,
StudentName varchar(100) not null,
StudentEmailID varchar(100) not null,
StudentPassword varchar(100) not null,
StudentCity varchar(100) not null,
StudentGender varchar(100) not null,
StudentImageAddress varchar(max) not null,
)

alter proc proc_addstudent(@name varchar(100),@emailid varchar(100),
			@pwd varchar(100),@city varchar(100),@gender varchar(100),@image varchar(100))
as
begin
insert tbl_students values(@name,@emailid,@pwd,@city,@gender,@image)
return @@identity
end


alter proc proc_update(@studentid int,@studentname varchar(100),@studentemail varchar(100))
as
begin
select * from tbl_students where StudentID=@studentid
update tbl_students set StudentName=@studentname , StudentEmailID=@studentemail Where StudentID=@studentid 
return @@rowcount
end


alter proc proc_find(@id int)
as
begin
select * from tbl_students where StudentID=@id
return @@identity
end

alter proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_students where StudentID=@id and StudentPassword=@pwd
return @count
end

alter proc proc_delete(@id int)
as
begin
delete tbl_students where StudentID=@id
return @@rowcount
end

alter proc proc_search(@key varchar(100))
as
begin
select * from tbl_students where StudentID like  '%'+@key+'%' or StudentName like '%'+@key+'%'
end
