Create database db_yogeshwari

use db_yogeshwari

Create table tbl_employees
(
EmployeeID int,
EmployeeName varchar(100),
EmployeeCity Varchar(100),
EmployeeSalary int,
EmployeeDOJ DateTime
)

insert tbl_employees values(1001,'John','BGL',30000,'12/12/2018')
insert tbl_employees values(1002,'David','Chennai',20000,'11/11/2018')
insert tbl_employees values(1003,'Yogeshwari','Tumkur',40000,'10/02/2018')
insert tbl_employees values(1004,'Pooja','Tumkur',45000,'12/02/2018')
insert tbl_employees values(1005,'Manushree','Banglore',50000,'11/02/2018')
insert tbl_employees values(1006,'Rosy','BGL',null,'10/10/2018')

Select * from tbl_employees

Select * from tbl_employees where EmployeeCity='BGL'

Select * from tbl_employees where EmployeeCity='BGL' and EmployeeSalary>20000

Select EmployeeID, EmployeeName,EmployeeCity from tbl_employees 

update tbl_employees set EmployeeSalary=35000 where EmployeeID=1001

update tbl_employees set EmployeeSalary=32000,EmployeeCity='BGL' where EmployeeID=1002

Select * from tbl_employees

delete tbl_employees where EmployeeID=1006 
-- supports where,trigger,used for deleting rows logically

truncate table tbl_Employees
-- Not Support: where ,trigger,used for cleaning the table rows(all)

--drop table tbl_employees

sp_help tbl_employees --to show the table defination

alter table tbl_employees add employeemobile varchar(10)

Select * from tbl_employees

alter table tbl_employees alter column employeename varchar(200)

alter table tbl_employees drop column employeemobile


Select * from tbl_employees where EmployeeCity in('BGL','Chennai')

Select * from tbl_employees where EmployeeSalary is null 

Select * from tbl_employees where EmployeeSalary between 30000 and 40000

Select * from tbl_employees

Select * from tbl_employees order by EmployeeSalary desc

Select * from tbl_employees where EmployeeCity='BGL' order by EmployeeSalary asc

Select * from tbl_employees order by EmployeeCity desc,employeename asc

Select top 1 * from tbl_employees order by EmployeeSalary desc
 
Select top 1 with ties * from tbl_employees where EmployeeSalary=50000 

Select len(Employeename),upper(EmployeeCity),SUBSTRING(employeename,1,8)
from tbl_employees where len(employeename)>1


Select sum(employeesalary) from tbl_employees

Select sum(EmployeeSalary) from tbl_employees where EmployeeCity='BGL'

select avg(employeesalary) from tbl_employees

Select max(employeesalary) from tbl_employees

Select min(employeesalary) from tbl_employees

Select count(*) from tbl_employees

Select count(*) from tbl_employees where EmployeeName='David'

Select * from tbl_employees where EmployeeSalary= min(EmployeeSalary)

Select getdate()

insert tbl_employees values(1008,'yogi','TMK',2000,getdate())

select employeeid ,dateadd(mm,1,employeedoj) from tbl_employees

Select * from tbl_employees

Select employeeid,employeename ,datediff(yy,employeedoj,getdate())
from tbl_employees

Select employeeid,employeename,datename(yy,employeedoj)from tbl_employees

Select datepart(dw,'10/12/1996')

select employeecity, count(*) from tbl_employees group by EmployeeCity

Select employeecity ,sum(employeesalary) from tbl_employees
where EmployeeSalary>10000
group by EmployeeCity
having sum(employeesalary)>40000


create table tbl_orders
(
OrderID int identity(1000,1),
CustomerName varchar(100),
OrderAmount int
)
insert tbl_orders values('John',2000)

insert tbl_orders values('David',4000)

insert tbl_orders values('yogi',5000)

select  @@IDENTITY

Select * from tbl_orders




select ISNull(1001,0)