create database db_users

create table tbl_user
(
UserID int identity(100,1) primary key,
FirstName varchar(100) not null,
LastName Varchar(100) not null,
City varchar(100) not null,
UserPassword varchar(100) not null
)

alter proc proc_adduser(@fname varchar(100),@lname varchar(100),
						@city varchar(100),@pwd varchar(100))
as
begin
insert tbl_user values(@fname,@lname,@city,@pwd)
return @@identity
end

select * from tbl_user

create proc proc_search(@id int)
as
begin
select * from tbl_user where UserID=@id