--OnlineFoodOrderingDB

create database OnlineFoodOrderingDB

--1. Create a Table called Restaurants
--	RestaurantID(PK,Auto), RestaurantName , RestaurantAddress , RestaurantCity , ContactNo

create table Restaurants
(
RestaurantID int identity(100,1) primary key,
RestaurantName varchar(100) not null,
RestaurantAddress varchar(100) not null,
RestaurantCity varchar(100) not null,
ContactNo varchar(100) not null unique
)

insert Restaurants values('Mcdonald','JP nagar','BGL','123456')
insert Restaurants values('Udupi restauranet','Rajajinagar','BGL','1112233')
insert Restaurants values('Arebic','Jayanagar','BGL','332244')
insert Restaurants values('Ammus','Kyathsandra','Tumkur','44225566')







--2. Create a Table called RMenuItems
--MenuID (PK , Auto) ,RestID (FK), MenuName , MenuType , MenuCategory , MenuPrice , MenuDesc

create table RMenuItems
(
MenuID int identity(1,1) primary key,
RestaurantID  int foreign key references Restaurants(RestaurantID),
MenuName varchar(100) not null,
MenuType varchar(100) not null,
MenuCategory varchar(100) not null,
MenuPrice int not null,
MenuDesc varchar(100) not null
)
select * from Restaurants
insert RMenuItems values(100,'Pizza','Veg','Nort indian',200,'chees')
insert RMenuItems values(100,'Burgar','Veg','North indian',300,'bread')
insert RMenuItems values(103,'Noodles','Veg','Chinees',500,'Spicy')

--3. Create a Table called Customers
---	CustomerID (PK, Email) , CustomerName , CustomerCity , CustomerDOB , CustomerGender , CustomerPassword

create table Customers
(
CustomerEmail varchar(100) not null primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerDOB DateTime,
CustomerGender varchar(100) check(CustomerGender in('Male','Female')),
CustomerPassword varchar(100)
)

insert Customers values('yogi@123','Yogeshwari','Tumkur','10/12/1996','Female','123')
insert Customers values('pooja@123','Pooja','Tumkur','02/09/1996','Female','234')
insert Customers values('Prabhu@123','Prabhu','BGL','06/12/1993','Male','456')

--4. Create a table called Orders
--	OrderID (PK, Auto) , CustomerID (FK) , OrderDate , DeliveryAddress , OrderStatus

Create table Orders
(
OrderID int identity(100,1) primary key,
CustomerEmail varchar(100) foreign key references Customers(CustomerEmail),
OrderDate DateTime,
DeliveryAddress varchar(100) not null,
OrderStatus varchar(100) not null
)

insert Orders values('yogi@123','12/08/2018','Kamakshipalya','Delivered')
insert Orders values('yogi@123','11/03/2018','Vijaynagar','Deliverd')
insert Orders values('pooja@123','10/08/2018','Kamakya','Deliverde')
insert Orders values('prabhu@123','02/12/2018','Magdi road','not delivered')

--5. Create a table called OrderMenus
--	OrderID (FK) , MenuID(FK) , MenuQty , MenuPrice 

create table OrderMenus
(
OrderID int foreign key references Orders(OrderID),
MenuID int foreign key references RMenuItems(MenuID),
MenuQty int not null,
MenuPrice int not null unique
)


insert OrderMenus values(100,1,2,3000)
insert OrderMenus values(100,2,3,4000)
insert OrderMenus values(101,1,4,2000)
insert OrderMenus values(101,5,4,2500)
insert OrderMenus values(103,1,3,4500)
insert OrderMenus values(104,2,2,1500)
insert OrderMenus values(105,5,4,2300)

--	Note : OrderID & MenuID should be together primary key.

--Add some dummy data in the tables


--Reports / Queries

--1. Show the list of Restaurant of specific city

select * from Restaurants
where RestaurantCity='BGL'

--2. Show the list of all Restaurants along with menus (RestaurantID , RestaurantName ,MenuID 
--, MenuName , MenuPrice)
select Restaurants.RestaurantID,Restaurants.RestaurantName,
	RMenuItems.MenuID,RMenuItems.MenuName,RMenuItems.MenuPrice
from Restaurants join RMenuItems
on
Restaurants.RestaurantID=RMenuItems.RestaurantID


--3. Show the list of  Restaurants along with menus (RestaurantID , RestaurantName ,MenuID , MenuName , MenuPrice) of specific city

select Restaurants.RestaurantID,Restaurants.RestaurantName,
	RMenuItems.MenuID,RMenuItems.MenuName,RMenuItems.MenuPrice
from Restaurants join RMenuItems
on
Restaurants.RestaurantID=RMenuItems.RestaurantID
where Restaurants.RestaurantCity='BGL'

--4. Show the list of Orders of a specific customer (based on customeremailid)
select * from Orders
select * from Orders
where CustomerEmail='yogi@123'
order by CustomerEmail desc


--5. Show the list of orders along with ordermenus (OrderID , CustomerEmailID , OrderDate , 
--MenuID , MenuQty , MenuPrice)

select Orders.OrderID,Orders.CustomerEmail,Orders.OrderDate,
		OrderMenus.MenuID,OrderMenus.MenuQty,OrderMenus.MenuPrice
from Orders join OrderMenus
on
Orders.OrderID=OrderMenus.OrderID



--6. Show the list of latest 5 orders of a specific customer (based on CustomerEmailiID)

select top 5 * from Orders
where CustomerEmail='yogi@123'
order by CustomerEMail desc

--7. Show the list of menus in price ascending order.

select * from OrderMenus
order by MenuPrice asc
--8. Show the list of cities along with number of restaurants

select count(*), RestaurantCity
from Restaurants
group by RestaurantCity


--9. Show the list of customers who never placed any order.
select * from Customers
where CustomerEmail
not in(select CustomerEmail from Orders)

--10. Show the menuitem details which has highest menuprice.(First)

select top 1 * from RMenuItems order by MenuPrice desc


--11. Show the menuitem details which has second highest menuprice.(Second)

Select top 1 * from RMenuItems where  MenuPrice in
(select top 2  MenuPrice from RMenuItems order by MenuPrice desc
) order by MenuPrice asc

