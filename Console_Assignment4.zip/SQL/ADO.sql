Create database db_batch9_ado

create table tbl_employees
(
EmployeeID int identity(1000,1),
EmployeeName varchar(100) not null,
EmployeePassword varchar(100) not null,
EmployeeCity varchar(100) not null,
EmployeeSalary int not null,
EmployeeDOJ datetime not null
)

create proc proc_addemployee(@name varchar(100),
						@pwd varchar(100),@city varchar(100),@salary int)
as
begin
insert tbl_employees values(@name,@pwd,@city,@salary,getdate());
return @@identity
end

create proc proc_updatemployee(@id int ,@city varchar(100),@salary int)
as
begin
update tbl_employees set EmployeeCity=@city,EmployeeSalary=@salary
where EmployeeID=@id
return @@rowcount
end

create proc proc_deleteemployee(@id int)
as
begin
delete tbl_employees where EmployeeID=@id
return @@rowcount
end


create proc proc_findemployee(@id int)
as
begin
select * from tbl_employees where EmployeeID=@id
return @@rowcount
end

create proc proc_searchemployee(@key varchar(100))
as
begin
select * from tbl_employees where EmployeeID like '%'+@key+'%'
											or EmployeeName like '%'+@key+'%'
end

create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int
select @count=count(*) from tbl_employees
where EmployeeID=@id and employeepassword=@pwd
return @count
end












