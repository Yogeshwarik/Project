Create database db_mvc_employee

Create table tbl_employees
(
EmployeeID int identity(1000,1) primary key,
EmployeeName varchar(100) not null,
EmployeeEmail varchar(100) not null,
EmployeeCity varchar(100) not null,
EmployeePassword varchar(100) not null,
EmployeeGender varchar(100) not null,
EmployeeImageAddress varchar(100) not null
)

create proc proc_addemployee(@name varchar(100),@email varchar(100),@city varchar(100),@pwd varchar(100),
							@gender varchar(100),@image varchar(100))
as
begin
insert tbl_employees values(@name,@email,@city,@pwd,@gender,@image)
return @@identity
end

create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_employees where EmployeeID=@id and EmployeePassword=@pwd
return @count
end

create proc proc_update(@employeeid int,@employeename varchar(100),@employeeemail varchar(100))
as
begin
select * from tbl_employees where EmployeeID=@employeeid
update tbl_employees set EmployeeName=@employeename,EmployeeEmail=@employeeemail where EmployeeID=@employeeid
return @@rowcount
end

create proc proc_find(@id int)
as
begin
select * from tbl_employees where EmployeeID=@id
return @@identity
end

create proc proc_delete(@id int)
as
begin
delete tbl_employees where EmployeeID=@id
return @@rowcount
end

create proc proc_search(@key varchar(100))
as
begin 
select * from tbl_employees where EmployeeID 
						like '%'+@key+'%' or EmployeeName like '%'+@key+'%'
end