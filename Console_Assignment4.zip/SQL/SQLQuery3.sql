--1. Create a procedure for adding a row in tbl_Customers table and return the rowcount


create proc pro_addrow(@customeremailid varchar(100),@customername varchar(100),
			@customercity varchar(100),@customermobileno varchar(100),@customergender varchar(100))
as
begin
insert tbl_customers values(@customeremailid,@customername,@customercity,@customermobileno,@customergender)
return @@rowcount
end
--2. Create a procedure for updating customer row based on customerid 
--(update customercity).
create proc proc_updatecustomercity(@customeremailid varchar(100),@customercity varchar(100))
as
begin
select * from tbl_customers where CustomerEmailID=@customeremailid
update tbl_customers set CustomerCity=@customercity where CustomerEmailid=@customeremailid
end
--3. Create a procedure for updating the customermobileno based on customerid and password.
---Procedure must take three parameters (CustomerID , CustomerPassword,NewMobileNo). 
--If CustomerID and CustomerPassword matches then only MobileNo can be updated.
-- Returns 0 or 1 as per the update.


create proc proc_updatemobileno(@customerid int,@customerpassword varchar(100),@NewMobileNo varchar(100))
as
begin
select * from CustomerInfo where CustomerID=@customerid
update Customerinfo set CustomeMobileNo=@NewMobileNo where CustomerID=@customerid 
														and CustomerPassword=@customerpassword
end

--4. Create a procedure for displaying (CustomerID , CustomerName , AccountID , AccountBalance)
-- based on customerid.(use join)
create proc proc_disp
as
begin
select CustomerInfo.CustomerID,CustomerInfo.CustomerName,AccountInfo.AccountID,AccountInfo.AccountBalance
from CustomerInfo join AccountInfo
on
CustomerInfo.CustomerID=AccountInfo.CustomerID

--5. Create a procedure for login (ID & Password) , if user enters three times wrong password on the same day then login should be blocked (return 0 , 1, -1)
	--(CustomerID , Password , Name , PasswordCount , Status , WrongPasswordAttemptDate)
	---- Add Rows using Procedure 

--6. Create a procdure to get customername , customercity using output parameters based on customerid as an input parameter
create proc pro_getcustomername(@customerid int,@customername varchar(100) output)
as
begin
select @customername=CustomerName from CustomerInfo where CustomerID=@customerid
end


--7. Create a function to concatenate customername , customercity , customeraddress and
-- use in a query.

create function concatinate(@customername varchar(100),@customercity varchar(100),
 @customeraddress varchar(100))
returns varchar(100)
as
begin
declare @concat varchar(100)
set @concat=@customername +','+@customercity+','+@customeraddress
return @concat
end

select CustomerName,CustomerCity,CustomerAddress ,
		dbo.concatinate(CustomerName,CustomerCity,CustomerAddress )from CustomerInfo


--8. Create a function to return account table output with a parameter customerid

create  function return_account(@customerid int)
returns table
return select * from AccountInfo where CustomerID=@customerid


--9. Create a Trigger for updating the account balance in the account table 
--as per the transaction (withdraw / deposit) in the transation table.(Use the Bank Database)

alter trigger trg_accountBalnce
on TransactionInfo
for  insert
as
begin
declare @accountid int
declare @amount int
declare @transactiontype varchar(100)
select @accountid=AccountID, @amount=Amount,@transactiontype=Transactiontype from inserted
if(@transactiontype='D')
begin
update AccountInfo set Accountbalance=accountbalance+@amount where accountid=@accountid
end
if(@transactiontype='C')
begin
update AccountInfo set Accountbalance=accountbalance-@amount where accountid=@accountid
end
end

insert TransactionInfo  values(1000,'D',2000,getdate())




select * from AccountInfo