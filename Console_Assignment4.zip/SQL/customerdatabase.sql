create database db_yogeshwari_ado

create table tbl_customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100) not null,
CustomerPassword varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerAddress varchar(100) not null,
CustomerMobileno varchar(100) not null unique,
CustomerEmailID varchar(100) not null
)
create proc proc_addcustomer(@name varchar(100), @pwd varchar(100),
				@city varchar(100),@address varchar(100), @mobileno varchar(100),@emailid varchar(100))
as
begin
insert tbl_customers values(@name,@pwd,@city,@address,@mobileno,@emailid)
return @@identity
end

create proc proc_findcustomer(@id int)
as
begin
select * from tbl_customers where CustomerID=@id;
return @@rowcount
end

create proc proc_searchcustomer(@key varchar(100))
as
begin
select * from tbl_customers where CustomerID like '%'+@key+'%'
											or CustomerName like '%'+@key+'%'
end

create proc proc_updatecustomer(@id int,@address varchar(100),@mobileno varchar(100))
as
begin
update tbl_customers set CustomerAddress=@address,CustomerMobileno=@mobileno
where CustomerID=@id
return @@rowcount
end

create proc proc_deletecustomer(@id int)
as
begin
delete tbl_customers where CustomerID=@id
return @@rowcount
end

create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int
select @count=count(*) from tbl_customers
where CustomerID=@id and CustomerPassword=@pwd
return @count
end



select * from tbl_customers




