Create database db_invoice_items
----------------------------------------------------------------------------
Create table tbl_customers
(
CustomerEmailID varchar(100) primary key,
CustomerName varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerMobileNo varchar(100) not null unique,
CustomerGender varchar(100) check (CustomerGender in ('Male','Female'))
)

insert tbl_customers values('yogi@123','Yogeshwari','Tumkur','12345678','Female')
insert tbl_customers values('pooja@123','Pooja','Tumkur','23145678','Female')
insert tbl_customers values('manu@123','Manushree','BGL','132456','Female')
insert tbl_customers values('prabhu@123','Prabhu','BGL','1425678','Male')
insert tbl_customers values('pankaja@123','Pankaja','Belgam','22334411','female')

select * from tbl_customers
-----------------------------------------------------------------------------------

Create table tbl_items
(
ItemID int identity(1,1) primary key,
ItemName varchar(100) not null,
ItemPrice int not null check(ItemPrice>0)
)

insert tbl_items values('PEN',10)
insert tbl_items values('Laptop',30000)
insert tbl_items values('Bag',2000)
insert tbl_items values('Watch',25000)
insert tbl_items values('Mouse',400)

select * from tbl_items
-----------------------------------------------------------------------------------------

Create table tbl_invoices
(
InvoiceID int identity(1000,1) primary key,
CustomerEmailID varchar(100) not null foreign key references tbl_customers(customeremailid),
InvoiceDate datetime not null,
InvoiceCity varchar(100)
)

insert tbl_invoices values('yogi@123','11/02/2018','BGL')
insert tbl_invoices values('yogi@123','10/23/2017','BGL')
insert tbl_invoices values('Pooja@123','09/21/2017','Pune')
insert tbl_invoices values('manu@123','08/24/2018','Tumkur')
insert tbl_invoices values('prabhu@123','02/12/2014','USA')

select * from tbl_invoices
------------------------------------------------------------------------------------

Create table tbl_invoiceitems
(
InvoiceID int foreign key references tbl_invoices(invoiceid),
ItemID int foreign key references tbl_items(itemid),
ItemQty int not null check(ItemQty>0),
ItemPrice int not null check(ItemPrice >0),
primary key (InvoiceID, ItemID)

)

insert tbl_invoiceitems values(1000,1,2,10)
insert tbl_invoiceitems values(1000,2,3,10)
insert tbl_invoiceitems values(1001,3,2,30000)
insert tbl_invoiceitems values(1002,4,2,400)
insert tbl_invoiceitems values(1002,2,3,2000)

select * from tbl_invoiceitems

----------------------------------------------------------------------

--SUB QUIRES

Select * from  tbl_customers
where CustomerEmailID 
in (Select CustomerEmailID from tbl_invoices)

Select * from  tbl_customers
where CustomerEmailID 
in (Select distinct CustomerEmailID from tbl_invoices)

Select * from tbl_customers
where CustomerEmailID
not in (Select distinct CustomerEmailID from tbl_invoices)

----------------------------------------------------------------------
Select * from tbl_items
where ItemID
in(select ItemID from tbl_invoiceitems)

Select * from tbl_items
where ItemID
not in(select ItemID from tbl_invoiceitems)


--Interview question----
Select top 1 * from tbl_items order by ItemPrice desc

--list of items which is second item price

Select top 1 * from tbl_items where ItemID in
(select top 2  itemid from tbl_items order by ItemPrice desc
) order by ItemPrice asc

---JOINS---

Select tbl_invoices.InvoiceID,tbl_invoices.InvoiceCity,tbl_invoices.InvoiceDate,tbl_invoices.CustomerEmailID,
	   tbl_customers.CustomerName,tbl_customers.CustomerMobileNo,
	   tbl_invoiceitems.ItemID,tbl_invoiceitems.ItemQty,
	   tbl_items.ItemName
from tbl_invoices join tbl_customers
on 
tbl_invoices.CustomerEmailID=tbl_customers.CustomerEmailID
join  tbl_invoiceitems
on
tbl_invoices.InvoiceID=tbl_invoiceitems.InvoiceID
join tbl_items
on
tbl_invoiceitems.ItemID=tbl_items.ItemID


Select tbl_invoices.InvoiceID,tbl_invoices.InvoiceDate,
	tbl_invoices.CustomerEmailID,
	tbl_customers.CustomerName,
	tbl_customers.CustomerMobileNo,
	tbl_customers.CustomerEmailID
	from tbl_invoices
	full outer join tbl_customers
	on
	tbl_invoices.CustomerEmailID=tbl_customers.CustomerEmailID

	select * from tbl_customers cross join tbl_invoices
-----------------------------------------------------------------------------------------

	declare @count int=0;
	set @count=1;
	select @count;
	while(@count<10)
	begin
	Select @count;
	set @count=@count+1;
	end
	Select @count;

	Select * from tbl_customers

	declare @count int=0;
	declare @emailid varchar(100)='abc@123.com'
	declare @name varchar(100)='ABC'
	declare @city varchar(100)='BGL'
	declare @mobile varchar(100)='12345'
	declare @gender varchar(100)='Male'

	select @count=count(*) from tbl_customers where CustomerEmailID=@emailid or 
													CustomerMobileNo=@mobile
	if(@count=0)
	begin
	insert tbl_customers values(@emailid,@name,@city,@mobile,@gender)
	end
	else
	begin
	select 'customer already  Exists with the same email or mobile' 
	end


Create proc proc_getcustomers
as
begin 
Select * from tbl_customers
end

exec proc_getcustomers

create proc proc_second_maxprice_item
as
begin
select top 1* from tbl_items where ItemID in
(select top 2 itemid  from tbl_items order by ItemPrice desc)
order by ItemPrice asc
end

exec proc_second_maxprice_item


alter proc proc_customers(@city varchar(100), @gender varchar(100) 
as
begin 
select * from tbl_customers where CustomerCity=@city and CustomerGender=@gender
end

exec proc_customers 'BGL'



create proc proc_find(@id varchar(100))
as
begin
select * from tbl_customers where CustomerEmailID=@id
end

exec  proc_find 'abc@123.com'


create proc pro_search(@key varchar(100))
as
begin
select * from tbl_customers where CustomerEmailID like '%'+@key+'%'
								or CustomerName like  '%'+@key+'%'
								or CustomerCity like '%'+@key+'%'
								or CustomerMobileNo like '%'+@key+'%'
end

exec pro_search '132'


---get the return value from procedure----
create proc pro_additem(@name varchar(100),@price int)
as
begin
insert tbl_items values(@name,@price)
return @@identity
end
--return value--
declare @id int 
exec @id=pro_additem 'Keyboard',35000
select @id
select * from tbl_items


create proc proc_updateitem (@1i int ,@price int )
as
begin
update tbl_items set ItemPrice=@price where ItemID=@id
end
return @@rowcount
end

declare @count int
exec @count=proc_updateitem 1,15000
select @count