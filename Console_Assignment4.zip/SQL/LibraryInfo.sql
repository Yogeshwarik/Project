create database LibraryInfo
 
create table tbl_students
(
StudentID int identity(1000,1),
StudnetName varchar(100) not null,
StudentEmail varchar(100) not null,
StudentDOB DateTime,
StudentPassword varchar(100) not null,
StudentGender varchar(100) not null,
StudnetImageAddress varchar(100) not null
)

create table tbl_books
(
BookID int identity(100,1),
BookName varchar(100) not null,
AuthorName varchar(100) not  null,
BookImage varchar(100) not null,
BookAddedDate Datetime 
);

create proc proc_addstudent(@name varchar(100),@email varchar(100),@dob DateTime,
								@password varchar(100),@gender varchar(100),@image varchar(100))
as
begin
insert tbl_students values(@name,@email,@dob,@password,@gender,@image)
return @@identity
end

alter proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_students where StudentID=@id and StudentPassword=@pwd
return @count
end

create proc proc_findstudent(@id int)
as
begin
select * from tbl_students where StudentID=@id 
return @@identity
end

create proc proc_addbook(@bookname varchar(100),@authorname varchar(100),@bookimage varchar(100))
as
begin
insert tbl_books values(@bookname,@authorname,@bookimage,getdate())
return @@identity
end

create proc proc_searchbook(@key varchar(100))
as
begin
select * from tbl_books where BookID like  '%'+@key+'%' or BookName like '%'+@key+'%'
end

delete tbl_students where StudentID=2009


delete tbl_students
