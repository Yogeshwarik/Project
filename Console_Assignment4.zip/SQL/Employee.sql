	--1. Create a Database named "Emp_DB"
Create database Emp_DB

use Emp_DB

--2. Create a Table named "Employees tbl_Employees
--EmployeeID (Auto) , EmployeeFName , EmployeeLName , EmployeeCity , 	
--	EmployeeDOB , EmployeeSalary , EmployeeStatus , EmployeeDOJ

Create table tbl_Employees
(
EmployeeID int identity(100,1),
EmployeeFName varchar(100),
EmployeeLName varchar(100),
EmployeeCity varchar(100),
EmployeeDOB Date,
EmployeeSalary int,
EmployeeStatus varchar(100),
EmployeeDOJ DateTime
)

--3. Add  columns named EmployeeDept & EmployeeDOJ in the tbl_Employees table

alter table tbl_Employees add EmployeeDeptName varchar(100)


select * from tbl_Employees

--4. Insert some records in the Employees table(min 10 rows).

Insert tbl_Employees values('Yogeshwari','K','Tumkur','10/12/1996',30000,'Working','01/21/2018','HR')

Insert tbl_Employees values('Pooja','M','Tumkur','02/09/1996',40000,'working','01/22/2018','Manager')

Insert tbl_Employees values('Prabhu','Kumar','BGL','03/10/1996',35000,'Working','02/22/2018','Chief Executive')

Insert tbl_Employees values('Manu','shree','BGL','08/26/1993',45000,'Working','03/21/2018','IT')

Insert tbl_Employees values('Pankaja','c','Chennai','04/23/1996',43000,'Working','03/23/2018','Software Design')

Insert tbl_Employees values('Latha','BK','Chennai','11/30/1996',50000,'Resigned','12/23/2017','Tesing')

Insert tbl_Employees values('Madhu','MA','Bagalore','11/06/1993',35000,'Working','12/06/2018','Development')

Insert tbl_Employees values('John','smith','Pune','12/12/1996',25000,'Resigned','12/4/2016','Tesing')

Insert tbl_Employees values('Kavya','shree','Pune','10/23/1995',48000,'Resigned','11/23/2016','Design')

Insert tbl_Employees values('Swathi','KB','Pune','03/12/1996',38000,'Working','12/16/2018','Developer')

Insert tbl_Employees values('Harry','potter','USA','12/03/1987',60000,'Working','1/21/2019','Tesing')



--Reports
--------

--5. Create a List of employees from 'Chennai' City

Select * from tbl_Employees where EmployeeCity='Chennai'


--6. Create a List of employees whose salary is between 25000 and 50000

Select * from tbl_Employees where EmployeeSalary between 25000 and 50000



--7. Create a List of employees (EmployeeFullName , EmployeeID , EmployeeCity)

select  EmployeeFName,EmployeeID,EmployeeCity from tbl_Employees


--8. Create a List of employees in the employeesalary desc order

select * from tbl_Employees order by EmployeeSalary desc

--9. Create a List of employees in the employeecity asc order

select * from tbl_Employees order by EmployeeSalary asc

--10. Create a List of Employees in the ascending order based on the length of their first name.

Select * from tbl_employees order by len(EmployeeFName) asc


--11. Show the employee details who is getting maximum/highest salary

select top 1 * from tbl_Employees order by EmployeeSalary desc

--12. Retrieve the sum of salary.

select sum(employeesalary) from tbl_Employees

--13. Retrieve the total number of employees.

select count(*) from tbl_Employees

--14. Create a List of employees who joined in Current Month.

 Select * from tbl_Employees where datediff(mm,EmployeeDoj,getdate())=1



--15. Create a List of employees whose experience is more than 5 years.

Select * from tbl_Employees where datediff(yy,EmployeeDoj,getdate())>5
 

--16. Create a List of employee department names with no of employees

select EmployeeDeptName,count(*)
from tbl_Employees
group by EmployeeDeptName


--17. Create a List of employee cities with count of employees

select EmployeeCity,count(*)
from tbl_Employees
group by EmployeeCity


--18. Update some employees city from Chennai to Pune

update tbl_Employees set EmployeeCity='Pune' where EmployeeCity='Chennai'

--19. Create a List of employee department with sum of salary where sum of salary is more than 50000


select EmployeeDeptName,sum(EmployeeSalary) from tbl_Employees
group by EmployeeDeptName
having sum(EmployeeSalary)>50000



--20. Change the status of some employee from working to resigned.

update tbl_Employees set EmployeeStatus='Resigned' where EmployeeStatus='Working' 


