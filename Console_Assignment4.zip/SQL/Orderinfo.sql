create database OrderInfo

create table tbl_students
(
StudentID int identity(1001,1),
StudentName varchar(100) not null,
StudentEmailID varchar(100) not null,
StudentDOB DateTime,
StudentPassword varchar(100) not null,
StudentGender varchar(100) not null,
StudentImage varchar(100) not null
)

create proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int
select @count=count(*) from tbl_students
where StudentID=@id and StudentPassword=@pwd
return @count
end

create proc proc_addstudent(@name varchar(100),@email varchar(100),
						@dob DateTime, @pwd varchar(100),@gender varchar(100),@image varchar(100))
as
begin
insert tbl_students values(@name,@email,@dob,@pwd,@gender,@image)
return @@identity
end

create proc proc_searchstudent(@key varchar(100))
as
begin
select * from tbl_students where StudentID like '%'+@key+'%'
											or StudentName like '%'+@key+'%'
end


create proc proc_showstudent(@studentid int)
as
begin
select * from tbl_students where StudentID=@studentid
end