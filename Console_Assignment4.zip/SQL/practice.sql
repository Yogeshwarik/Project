create database db_Banking

create table tbl_customers
(
CustomerID int identity(1000,1) primary key,
CustomerName varchar(100) not null,
CustomerPassword varchar(100) not null,
CustomerCity varchar(100) not null,
CustomerMobileno varchar(100) not null,
CustomerEmail varchar(100) not null,
CustomerAddress varchar(100) not null,
CustomerGender varchar(100) not null,
CustomerImageAddress varchar(100) not null
)



alter proc proc_addcustomer(@name varchar(100),@pwd varchar(100),@city varchar(100),
							@mobile varchar(100),@email varchar(100),
							@address varchar(100),@gender varchar(100),@image varchar(100))
as
begin
insert tbl_customers values(@name,@pwd,@city,@mobile,@email,@address,@gender,@image)
return @@rowcount
end

alter proc proc_findcustomer(@id int)
as
begin
select * from tbl_customers where CustomerID=@id
return @@identity
end

alter proc proc_searchcustomer(@key int)
as
begin
select * from tbl_customers where CustomerID like '%'+@key+'%' or CustomerName like '%'+@key+'%'
end

alter proc proc_updatecustomer(@id varchar(100),@name varchar(100),@email varchar(100))
as
begin
select * from tbl_customers where CustomerID=@id
update tbl_customers set CustomerName=@name,CustomerEmail=@email where CustomerID=@id
end

alter proc proc_login(@id int,@pwd varchar(100))
as
begin
declare @count int=0
select @count=count(*) from tbl_customers where CustomerID=@id and CustomerPassword=@pwd
return @count
end

create proc proc_delete(@id int)
as
begin
delete tbl_customers where CustomerID=@id
return @@rowcount
end


