--Create a Database named BankDB 

create database BankDB

-----------------------
Tables
-----
--1. CustomersInfo with Auto gen CustomerID
  -- (CustomerID(PK) , CustomerName, CustomerCity, CustomerAddress , CustomerMobileNo(U), 
  --PAN (U), CustomerPassword , CustomerEmailID (U) )
---
 Create table CustomerInfo
 (
  CustomerID int identity(100,1) primary key,
  CustomerName varchar(100) not null,
  CustomerCity varchar(100) not null ,
  CustomerAddress varchar(100) not null,
  CustomeMobileNo varchar(100) not null unique,
  PAN varchar(100) not null unique,
  CustomerPassword varchar(100) not null,
  CustomerEmailID varchar(100) not null unique
  )

 insert CustomerInfo values('Yogeshwari','Tumkur','Kallur','1233456','1ab234','123','yogi@123')
 insert CustomerInfo values('Pooja','Tumkur','Kythsandra','11223344','2db123','234','pooja@123')
 insert CustomerInfo values('prabhu','BGL','Jayanagar','22445566','3bb321','567','prabhu@123')
 insert CustomerInfo values('manushree','BGN','Vidyaranyapura','4567898','bb456','789','manu@123')
 insert CustomerInfo values('Madhu','Banglore','Madivala','54322345','mm123','456','madhu@123')

--2. AccountInfo with auto gen AccountID
--   (AccountID(PK),CustomerID(FK),AccountType,AccountBalance,AccountOpenDate, 
--AccountStatus(Open,Closed,Blocked)) 

Create table AccountInfo 
(
AccountID int identity(1000,1) primary key,
CustomerID int foreign key references CustomerInfo(CustomerID),
AccountType varchar(100) not null,
AccountBalance int not null,
AccountOpenDate DateTime not null,
AccountStatus varchar(100) not null,
)
select * from CustomerInfo
insert AccountInfo values(100,'saving',30000,'11/23/2016','open')
insert AccountInfo values(100,'current',40000,'10/12/2016','closed')
insert AccountInfo values(101,'saving',30000,'08/23/2017','open')
insert AccountInfo values(101,'current',5000,'03/12/2018','closed')
insert AccountInfo values(102,'saving',45000,'08/22/2017','open')
insert AccountInfo values(102,'current',50000,'03/11/2018','closed')



--3. TransactionInfo with Auto gen TransactionID
 --  (TransactionID (PK),AccountID (FK),TransactionType (D,C),Amount (>0),TransactionDate)

 Create table TransactionInfo
 (
 TransactionID int identity(1,1) primary key,
 AccountID int foreign key references AccountInfo(AccountID),
 TransactionType varchar(100) not null,
 Amount int not null check(Amount>0),
 TransactionDate DateTime,
 )
 select * from AccountInfo
 insert TransactionInfo values(1000,'D',2000,'12/10/2018')
 insert TransactionInfo values(1000,'C',3000,'12/23/2018')
 insert TransactionInfo values(1001,'D',4000,'09/23/2018')
 insert TransactionInfo values(1001,'C',3000,'11/21/2018')
 insert TransactionInfo values(1002,'D',5000,'06/12/2017')
 insert TransactionInfo values(1003,'C',2000,'04/21/2018')

 select * from TransactionInfo
--Enter some test data (min 10 rows)





--Reports
--1. Latest 5 transactions of an account (Enter Account ID as an Input).

select top 5 * from TransactionInfo
where AccountID=1001
order by TransactionDate desc


--2. Transaction between two dates of an account (Enter Account ID as an Input)

select * from TransactionInfo
where AccountID=1001 and TransactionDate between '06/12/2017' and  '09/23/2018'


--3. List of Accounts of a Customer (Enter Customer ID as an input)

select * from AccountInfo
where CustomerID=100


--4. List of customers(CustomerID,CustomerName,CustomerAddress,CustomerMobileNo, AccountID , AccountBalance).

Select CustomerInfo.CustomerID,CustomerInfo.CustomerName,CustomerInfo.CustomerAddress,
		CustomerInfo.CustomeMobileNo,AccountInfo.AccountID,AccountInfo.AccountBalance
from CustomerInfo join AccountInfo
on
CustomerInfo.CustomerID=AccountInfo.CustomerID



--5. List of accounts with transactions (AccountID , AccountBalance , TransID , Amount, TransationType).

Select AccountInfo.AccountID,AccountInfo.AccountBalance,
		TransactionInfo.TransactionID,TransactionInfo.Amount,
		TransactionInfo.TransactionType
from AccountInfo join TransactionInfo
on
AccountInfo.AccountID=TransactionInfo.AccountID

--6. List of customers with accounts and transations (CustomerID,CustomerName,CustomerAddress,
--CustomerMobileNo, AccountID , AccountBalance,TransationID , Amount, TransationType)


select CustomerInfo.CustomerID,CustomerInfo.CustomerName,CustomerInfo.CustomerAddress,
		CustomerInfo.CustomeMobileNo,
		AccountInfo.AccountID,AccountInfo.AccountBalance,
		TransactionInfo.TransactionID,TransactionInfo.Amount,
		TransactionInfo.TransactionType
from CustomerInfo join AccountInfo
on
CustomerInfo.CustomerID=AccountInfo.CustomerID
join TransactionInfo
on
AccountInfo.AccountID=TransactionInfo.AccountID


--7. List of Customers who have accounts

select * from CustomerInfo
where CustomerID
in (select CustomerID from AccountInfo)

--8. List of Customer who have no account.

select * from CustomerInfo
where CustomerID
not in (select CustomerID from AccountInfo)

--9. List of Account which has transaction.

select * from AccountInfo
where AccountID
in (select AccountID from TransactionInfo)

--10. List of Account which has no transaction

select * from AccountInfo
where AccountID
not in(select AccountID from TransactionInfo)

--Note : A customer can have multiple accounts. Implement data integrity.

 



