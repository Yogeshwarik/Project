﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Console_Collections_Generic
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList names = new ArrayList();
            Console.WriteLine(names.Count);
            names.Add("John");//0 object o="john";
            names.Add("David");//1
            int i = 10000;
            names.Add(i);//object o=i;
            names[0] = "yogi";

            string s = names[0].ToString();
            for(int c=0;c<names.Count;c++)
            {
                string str = names[c].ToString();
                Console.WriteLine(str);
            }
            foreach(string s1 in names)
            {
                Console.WriteLine(s1);
            }
            Console.WriteLine(names.Count);
            names.Remove("John");
            names.RemoveAt(0);

            Console.WriteLine(names.Count);
            names.Clear();
            Console.ReadLine();


        }
    }
}
