﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Duplicate
{
    class Program
    {
        static void Main(string[] args)
        {
            string str = "Hello Dotnet";
            char[] ch = str.ToCharArray();

            for(int i=0;i<str.Length;i++)
            {
                for (int k=i+1;k<str.Length;k++)
                {
                    if(ch[i]==ch[k])
                    {

                        Console.WriteLine("dupicate elements:");
                        Console.WriteLine(ch[i]);
                        break;
                    }
                }

            }
            Console.ReadLine();
        }
    }
}
