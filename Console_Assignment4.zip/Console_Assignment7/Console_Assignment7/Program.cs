﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
            Ebook obj = new Ebook(123, "C#", "ABC", 500, 600, 500, "PDF");

            Console.WriteLine(obj.PBookID);
            Console.WriteLine(obj.PBookTitle);
            Console.WriteLine(obj.PAuthor);
            Console.WriteLine(obj.PPrice);
            Console.WriteLine(obj.PNoOfPages);
            Console.WriteLine(obj.PSize);
            Console.WriteLine(obj.PFormat);

            Console.ReadLine();

        }
    }
}
