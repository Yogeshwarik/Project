﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment7
{
    class Ebook : Book
    {
        private int Size;
        private string Format;

        public Ebook(int BookID,string BookTitle,string Author,int Price,
            int NoOfPages,int Size,string Format)
            :base(BookID,BookTitle,Author,Price,NoOfPages)
        {
            this.Size = Size;
            this.Format = Format;
        } 
        public int PSize
        {
            get
            {
                return this.Size;
            }
        }
        public string PFormat
        {
            get
            {
                return this.Format;
            }
        }
    }
}
