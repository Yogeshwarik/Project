﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment7
{
    class Book
    { 
        protected int BookID;
        protected string BookTitle;
        protected string Author;
        protected int Price;
        protected int NoOfPages;

        public Book(int BookID,string BookTitle,string Author,int Price,int NoOfPages)
        {
            this.BookID = BookID;
            this.BookTitle = BookTitle;
            this.Author = Author;
            this.Price = Price;
            this.NoOfPages = NoOfPages;
        }
        public int PBookID
        {
            get
            {
                return this.BookID;
            }
        }
        public string PBookTitle
        {
            get
            {
                return this.BookTitle;
            }
        }
        public string PAuthor
        {
            get
            {
                return this.Author;
            }
        }
        public int PPrice
        {
            get
            {
                return this.Price;
            }
        }
        public int PNoOfPages
        {
            get
            {
                return this.NoOfPages;
            }
        }
    }
}
