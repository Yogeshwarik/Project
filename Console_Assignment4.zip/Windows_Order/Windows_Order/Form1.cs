﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Windows_Order
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("Chennai");
            ddl_cities.Items.Add("Mumbai");
            ddl_cities.Items.Add("Pune");

            ddl_quantity.Items.Add(1);
            ddl_quantity.Items.Add(2);
            ddl_quantity.Items.Add(3);
            ddl_quantity.Items.Add(4);
            ddl_quantity.Items.Add(5);

        }

        private void btn_placeorder_Click(object sender, EventArgs e)
        {
            if (txt_customername.Text == string.Empty)
            {
                MessageBox.Show("Enter the Customer name");
            }
            else if (txt_itemname.Text == string.Empty)
            {
                MessageBox.Show("Enter the Item Name");
            }

            else if (txt_itemprice.Text == string.Empty)
            {
                MessageBox.Show("Enter the Item price");

            }
            else if (ddl_quantity.Text == string.Empty)
            {
                MessageBox.Show("Enter the Item Quantity");

            }

            
            else if (ddl_cities.Text == string.Empty)
            {
                MessageBox.Show("Select order a City");
            }
            else if (rdb_onlinepayment.Checked == false && rdb_cashondelivery.Checked == false)
            {
                MessageBox.Show("Select Payment Option");
            }
            else
            {
                string customername = txt_customername.Text;
                string itemname = txt_itemname.Text;
                int itemprice =Convert.ToInt32(txt_itemprice.Text);
                int quantity = Convert.ToInt32(ddl_quantity.Text);
                string city = ddl_cities.Text;
                string payment = string.Empty;


                if (rdb_onlinepayment.Checked == true)
                {
                    payment = "Online payment";
                }
                else
                {
                    payment = "Cash On Delivery";
                }

                Order obj = new Order(customername, itemname, itemprice, quantity);
                int id = obj.POrderID;
               
                MessageBox.Show("The order id genrated "+id.ToString());


                int total = obj.GetOrderValue();
                MessageBox.Show("Order value is:"+ total.ToString());
                
                



            }
        }
    }
}
