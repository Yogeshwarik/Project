﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Windows_Order
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string Itemname;
        private int Itemprice;
        private int Itemquantity;
        private static int Count = 100;
        

        public Order(string CustomerName, string Itemname, int Itemprice,
            int Itemquantity)
        {
            this.OrderID = ++Order.Count;
            this.CustomerName = CustomerName;
            this.Itemname = Itemname;
            this.Itemprice = Itemprice;
            this.Itemquantity = Itemquantity;
        }
        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public string PItemName
        {
            get
            {
                return this.Itemname;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.Itemprice;
            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.Itemquantity;
            }
        }
        public int GetOrderValue()
        {
            int total = Itemquantity * Itemprice;
            return total;
        }
    }
}
