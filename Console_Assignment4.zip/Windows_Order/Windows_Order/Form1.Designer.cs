﻿namespace Windows_Order
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_customername = new System.Windows.Forms.Label();
            this.lbl_itemname = new System.Windows.Forms.Label();
            this.lbl_itemprice = new System.Windows.Forms.Label();
            this.lbl_itemquantity = new System.Windows.Forms.Label();
            this.lbl_ordercity = new System.Windows.Forms.Label();
            this.lbl_paymentoption = new System.Windows.Forms.Label();
            this.txt_customername = new System.Windows.Forms.TextBox();
            this.txt_itemname = new System.Windows.Forms.TextBox();
            this.txt_itemprice = new System.Windows.Forms.TextBox();
            this.ddl_quantity = new System.Windows.Forms.ComboBox();
            this.ddl_cities = new System.Windows.Forms.ComboBox();
            this.rdb_onlinepayment = new System.Windows.Forms.RadioButton();
            this.rdb_cashondelivery = new System.Windows.Forms.RadioButton();
            this.btn_placeorder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_customername
            // 
            this.lbl_customername.AutoSize = true;
            this.lbl_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_customername.Location = new System.Drawing.Point(119, 61);
            this.lbl_customername.Name = "lbl_customername";
            this.lbl_customername.Size = new System.Drawing.Size(157, 24);
            this.lbl_customername.TabIndex = 0;
            this.lbl_customername.Text = "Customer Name :";
            // 
            // lbl_itemname
            // 
            this.lbl_itemname.AutoSize = true;
            this.lbl_itemname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemname.Location = new System.Drawing.Point(119, 104);
            this.lbl_itemname.Name = "lbl_itemname";
            this.lbl_itemname.Size = new System.Drawing.Size(111, 24);
            this.lbl_itemname.TabIndex = 1;
            this.lbl_itemname.Text = "Item Name :";
            // 
            // lbl_itemprice
            // 
            this.lbl_itemprice.AutoSize = true;
            this.lbl_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemprice.Location = new System.Drawing.Point(119, 157);
            this.lbl_itemprice.Name = "lbl_itemprice";
            this.lbl_itemprice.Size = new System.Drawing.Size(103, 24);
            this.lbl_itemprice.TabIndex = 2;
            this.lbl_itemprice.Text = "Item Price :";
            // 
            // lbl_itemquantity
            // 
            this.lbl_itemquantity.AutoSize = true;
            this.lbl_itemquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_itemquantity.Location = new System.Drawing.Point(119, 223);
            this.lbl_itemquantity.Name = "lbl_itemquantity";
            this.lbl_itemquantity.Size = new System.Drawing.Size(128, 24);
            this.lbl_itemquantity.TabIndex = 3;
            this.lbl_itemquantity.Text = "Item Quantity :";
            // 
            // lbl_ordercity
            // 
            this.lbl_ordercity.AutoSize = true;
            this.lbl_ordercity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ordercity.Location = new System.Drawing.Point(119, 279);
            this.lbl_ordercity.Name = "lbl_ordercity";
            this.lbl_ordercity.Size = new System.Drawing.Size(94, 24);
            this.lbl_ordercity.TabIndex = 4;
            this.lbl_ordercity.Text = "Order City";
            // 
            // lbl_paymentoption
            // 
            this.lbl_paymentoption.AutoSize = true;
            this.lbl_paymentoption.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_paymentoption.Location = new System.Drawing.Point(119, 337);
            this.lbl_paymentoption.Name = "lbl_paymentoption";
            this.lbl_paymentoption.Size = new System.Drawing.Size(154, 24);
            this.lbl_paymentoption.TabIndex = 5;
            this.lbl_paymentoption.Text = "Payment Option :";
            // 
            // txt_customername
            // 
            this.txt_customername.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_customername.Location = new System.Drawing.Point(322, 54);
            this.txt_customername.Name = "txt_customername";
            this.txt_customername.Size = new System.Drawing.Size(174, 29);
            this.txt_customername.TabIndex = 6;
            // 
            // txt_itemname
            // 
            this.txt_itemname.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemname.Location = new System.Drawing.Point(322, 104);
            this.txt_itemname.Name = "txt_itemname";
            this.txt_itemname.Size = new System.Drawing.Size(174, 29);
            this.txt_itemname.TabIndex = 7;
            // 
            // txt_itemprice
            // 
            this.txt_itemprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_itemprice.Location = new System.Drawing.Point(322, 154);
            this.txt_itemprice.Name = "txt_itemprice";
            this.txt_itemprice.Size = new System.Drawing.Size(174, 29);
            this.txt_itemprice.TabIndex = 8;
            // 
            // ddl_quantity
            // 
            this.ddl_quantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_quantity.FormattingEnabled = true;
            this.ddl_quantity.Location = new System.Drawing.Point(322, 215);
            this.ddl_quantity.Name = "ddl_quantity";
            this.ddl_quantity.Size = new System.Drawing.Size(174, 32);
            this.ddl_quantity.TabIndex = 9;
            // 
            // ddl_cities
            // 
            this.ddl_cities.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_cities.FormattingEnabled = true;
            this.ddl_cities.Location = new System.Drawing.Point(322, 279);
            this.ddl_cities.Name = "ddl_cities";
            this.ddl_cities.Size = new System.Drawing.Size(174, 32);
            this.ddl_cities.TabIndex = 10;
            // 
            // rdb_onlinepayment
            // 
            this.rdb_onlinepayment.AutoSize = true;
            this.rdb_onlinepayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_onlinepayment.Location = new System.Drawing.Point(334, 337);
            this.rdb_onlinepayment.Name = "rdb_onlinepayment";
            this.rdb_onlinepayment.Size = new System.Drawing.Size(162, 28);
            this.rdb_onlinepayment.TabIndex = 11;
            this.rdb_onlinepayment.TabStop = true;
            this.rdb_onlinepayment.Text = "Online Payment";
            this.rdb_onlinepayment.UseVisualStyleBackColor = true;
            // 
            // rdb_cashondelivery
            // 
            this.rdb_cashondelivery.AutoSize = true;
            this.rdb_cashondelivery.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rdb_cashondelivery.Location = new System.Drawing.Point(334, 371);
            this.rdb_cashondelivery.Name = "rdb_cashondelivery";
            this.rdb_cashondelivery.Size = new System.Drawing.Size(174, 28);
            this.rdb_cashondelivery.TabIndex = 12;
            this.rdb_cashondelivery.TabStop = true;
            this.rdb_cashondelivery.Text = "Cash On Delivery";
            this.rdb_cashondelivery.UseVisualStyleBackColor = true;
            // 
            // btn_placeorder
            // 
            this.btn_placeorder.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_placeorder.Location = new System.Drawing.Point(123, 435);
            this.btn_placeorder.Name = "btn_placeorder";
            this.btn_placeorder.Size = new System.Drawing.Size(124, 46);
            this.btn_placeorder.TabIndex = 13;
            this.btn_placeorder.Text = "Place Order\r\n";
            this.btn_placeorder.UseVisualStyleBackColor = true;
            this.btn_placeorder.Click += new System.EventHandler(this.btn_placeorder_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 531);
            this.Controls.Add(this.btn_placeorder);
            this.Controls.Add(this.rdb_cashondelivery);
            this.Controls.Add(this.rdb_onlinepayment);
            this.Controls.Add(this.ddl_cities);
            this.Controls.Add(this.ddl_quantity);
            this.Controls.Add(this.txt_itemprice);
            this.Controls.Add(this.txt_itemname);
            this.Controls.Add(this.txt_customername);
            this.Controls.Add(this.lbl_paymentoption);
            this.Controls.Add(this.lbl_ordercity);
            this.Controls.Add(this.lbl_itemquantity);
            this.Controls.Add(this.lbl_itemprice);
            this.Controls.Add(this.lbl_itemname);
            this.Controls.Add(this.lbl_customername);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_customername;
        private System.Windows.Forms.Label lbl_itemname;
        private System.Windows.Forms.Label lbl_itemprice;
        private System.Windows.Forms.Label lbl_itemquantity;
        private System.Windows.Forms.Label lbl_ordercity;
        private System.Windows.Forms.Label lbl_paymentoption;
        private System.Windows.Forms.TextBox txt_customername;
        private System.Windows.Forms.TextBox txt_itemname;
        private System.Windows.Forms.TextBox txt_itemprice;
        private System.Windows.Forms.ComboBox ddl_quantity;
        private System.Windows.Forms.ComboBox ddl_cities;
        private System.Windows.Forms.RadioButton rdb_onlinepayment;
        private System.Windows.Forms.RadioButton rdb_cashondelivery;
        private System.Windows.Forms.Button btn_placeorder;
    }
}

