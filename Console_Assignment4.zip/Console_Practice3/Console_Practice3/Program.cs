﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Practice3
{
    class Program
    {
        static void Main(string[] args)
        {
            /*Account obj = new Account(1, "abc", 5000);
            int id = obj.GetAccountID();
            string name = obj.GetCustomerName();
            int balance = obj.GetBalance();


            Console.WriteLine("Account ID:" + id);
            Console.WriteLine("Name:" + name);
            Console.WriteLine("Balance:" + balance);

            obj.deposite(2000);
            balance = obj.GetBalance();
            Console.WriteLine("Depodite succefully");

            obj.withdraw(1000);
            balance = obj.GetBalance();
            Console.WriteLine("withdraw successfully");
            Console.ReadLine();*/

            /*    Employee obj1 = new Employee(12, "yogi", 22, 6000);
                int id = obj1.GetEmployeeID();
                string name = obj1.GetEmployeeName();
                int age = obj1.GetEmployeeAge();
                int salary = obj1.GetEmployeeSalary();

                Console.WriteLine("Employee ID :" + id);
                Console.WriteLine("Name :" + name);
                Console.WriteLine("age:" + age);
                Console.WriteLine("salary:" + salary);


                obj1.HappyBirthDay();
                age = obj1.GetEmployeeAge();

                Console.WriteLine("updated age:" + age);

                obj1.GetSalaryIncrement(2000);
                salary = obj1.GetEmployeeSalary();

                Console.WriteLine("Increment salary:" + salary);*/

            Order obj2 = new Order(11, "Yogi", "PEN", 2, 10);
            int id = obj2.GetOrderID();
            string name = obj2.GetCustomerName();
            string itemname = obj2.GetItemName();
            int quantity = obj2.GetItemQuantity();
            int price = obj2.GetItemPrice();

            Console.WriteLine("Item ID:" + id);
            Console.WriteLine("Customer Name:" + name);
            Console.WriteLine("Item Name:" + itemname);
            Console.WriteLine("Quantity:" + quantity);
            Console.WriteLine("Price :" + price);

           int total= obj2.GetOrderAmount();
            Console.WriteLine("Order Amount:" + total);

            obj2.GetItemQuantity(4);
            quantity = obj2.GetItemQuantity();

            Console.WriteLine("Updated quantity:" + quantity);
            

            Console.ReadLine();
        }
    }
}
