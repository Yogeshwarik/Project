﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestLibrary
{
    public class Test
    {
        public int GetSalary(int perdaysalary,int noofdays)
        {
            return perdaysalary * noofdays;
        }

    }
}
