﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Student obj = new Student("yogi", 75);

            Console.WriteLine(obj.PStudentID);
            Console.WriteLine(obj.PStudentName);
            Console.WriteLine(obj.PStudentMarks);

            obj.PStudentName = "ABC";
            obj.PStudentMarks = 1001;

            Console.WriteLine(obj.PStudentName);
            Console.WriteLine(obj.PStudentMarks);

            obj.PStudentMarks = 45;
            Console.WriteLine(obj.PStudentMarks);

            /*Student obj1 = new Student("pooja", 85);
            obj1.PStudentName = "ABC";
            obj1.PStudentMarks = 80;
            Console.WriteLine("Student marks:" + obj1.PStudentMarks);
            
            Console.WriteLine(obj1.PStudentName);*/

            Console.ReadLine();
        }
    }
}
