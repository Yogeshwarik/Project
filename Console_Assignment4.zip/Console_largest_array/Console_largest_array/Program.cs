﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_largest_array
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = new int[10];
            int i;
            Console.WriteLine("Enter the size of an array");
            int size = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the elements of an array");
            for(i=0;i<size;i++)
            {
                a[i] = Convert.ToInt32(Console.ReadLine());
            }
            int largest = a[0];
            for(i=0;i<size;i++)
            {
                if(a[i]>largest)
                {
                    largest = a[i];
                }
            }
            Console.WriteLine("Largest element in an array:" + largest);

            Console.ReadLine();
        }
    }
}
