﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter The Name");
            string name = Console.ReadLine();

            Console.WriteLine("Enter Your Salary");
            double salary = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Enter The Type of Employee");
            string type = Console.ReadLine();

            //Employee obj = new Employee(name, salary);

            Employee obj = null;

            if(type=="Employee")
            {
                obj = new Employee(name, salary);
            }
            else if(type=="Employee_Contract")
            {
                obj = new Employee_Contract(name, salary);
            }
            else if(type=="Employee_Trainee")
            {
                obj = new Employee_Trainee(name, salary);
            }
            if (obj != null)
            {

                Console.WriteLine("Employee ID :" + obj.PEmployeeID);
                Console.WriteLine("Employee Name :" + obj.PEmployeeName);
                Console.WriteLine("Employee Salary:" + obj.PEmployeeSalary);

                string work = obj.GetWork();
                Console.WriteLine("Work Deatails:" + work);

                Console.WriteLine("Enter Number Of Days");
                int days = Convert.ToInt32(Console.ReadLine());

                double monthlysalary = obj.GetSalary(days);
                Console.WriteLine("Monthly salary :" + monthlysalary);
            }
            Console.ReadLine();

        }
    }
}
