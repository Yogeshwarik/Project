﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Employee_Contract : Employee
    {
        public Employee_Contract(string EmployeeName,double employeeSalary)
            :base(EmployeeName,employeeSalary)
        {
            Console.WriteLine("Employee contract Object Constructor");
        }
        public override double GetSalary(int Days)
        {
            double salary = this.EmployeeSalary / 30 * Days;
            return salary;
        }


    }
}
