﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Overriding
{
    class Employee_Trainee : Employee
    {
        public Employee_Trainee(string EmployeeName, double employeeSalary)
            : base(EmployeeName, employeeSalary)
        {
            Console.WriteLine("Employee Trainee Object");
        }
        public override double GetSalary(int Days)
        {
            return base.GetSalary(Days);
        }
    }
}
