﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Orderassignment
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        protected int ItemQuantity;
        protected int ItemPrice;
        private static int Count = 1000;

        public Order(string CustomerName,int ItemQuantity,int ItemPrice)
        {
            this.OrderID = ++Order.Count;
            this.CustomerName = CustomerName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;
        }
        public int POrderID
        {
            get
            {
                return this.OrderID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PItemQuantity
        {
            get
            {
                return this.ItemQuantity;
            }
        }
        public int PItemPrice
        {
            get
            {
                return this.ItemPrice;
            }
        }
        public virtual int GetOrderValue()
        {
            int total = ItemQuantity * ItemPrice;
            return total;
        }
    }
}
