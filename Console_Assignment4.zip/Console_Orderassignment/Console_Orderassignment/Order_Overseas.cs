﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Orderassignment
{
    class Order_Overseas : Order
    {
        public Order_Overseas(string CustomerName,int ItemQuantity,int ItemPrice)
            :base(CustomerName,ItemQuantity,ItemPrice)
        {
            Console.WriteLine("Oreder Overseas object");
        }
        public override int GetOrderValue()
        {
            int total = ItemQuantity * ItemPrice;
            total = total + (total * 10) / 100;
            return total;
        }
    }
}
