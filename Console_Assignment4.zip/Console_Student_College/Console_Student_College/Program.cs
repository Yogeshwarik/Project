﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Program
    {
        static void Main(string[] args)
        {
            College cobj = new College(1001, "pathfront");
            Console.WriteLine("College ID:" + cobj.PCollegeID);
            Console.WriteLine("College Name:" + cobj.PCollegeName);

            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1.Add,2.Find,3.Showall,4.Remove ,5.Request leave, 6.Exit");
                int opt = Convert.ToInt32(Console.ReadLine());
                switch(opt)
                {
                    case 1:
                        {
                            Console.WriteLine("enter the student name:");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter the Student Email Id");
                            string emailid = Console.ReadLine();
                            Student s = new Student(name, emailid);
                            cobj.AddStudent(s);
                            Console.WriteLine("Student Added:" + s.PStudentID);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("enter the student ID:");
                            int id = Convert.ToInt32(Console.ReadLine());

                            Student s = cobj.FindStudent(id);
                            if(s!=null)
                            {
                                Console.WriteLine(s.PStudentID);
                                Console.WriteLine(s.PStudentName);
                            }
                            else
                            {
                                Console.WriteLine("Student not Found");
                            }
                            break;
                        }
                    case 3:
                        {
                            cobj.ShowAll();
                            break;
                        }
                    case 4:
                        {
                            Console.WriteLine("Enter the Student Id:");
                            int id = Convert.ToInt16(Console.ReadLine());
                            bool status = cobj.Remove(id);
                            if(status==true)
                            {
                                Console.WriteLine("Remove successfully");
                            }
                            else
                            {
                                Console.WriteLine("Not found");
                            }
                            break;

                        }
                    case 5:
                        {
                            Console.WriteLine("Enter the student Id");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Student s = cobj.FindStudent(id);
                            if(s!=null)
                            {
                                Console.WriteLine("Enter the Leave Reason");
                                string reason = Console.ReadLine();
                                s.RequestLeave(reason);
                            }
                            else
                            {
                                Console.WriteLine("Not Found");
                            }
                            break;
                        }
                    case 6:
                        {
                            flag = false;
                            break;

                        }
                    default:Console.WriteLine("Invalid option");
                        {
                            break;
                        }
                }
            }
        }
    }
}
