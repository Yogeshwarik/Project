﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class Student
    {
        //publisher
        public delegate void delleave(int studentid, string msg);//delegate defination
        public event delleave evtleave;//Member of class (object member)//event defination


        private int StudentID;
        private string StudentName;
        private string StudentEmailID;
        private static int Count = 1000;

       public Student(string StudentName,string StudentEmailID)
        {
            this.StudentID = ++Student.Count;
            this.StudentName = StudentName;
            this.StudentEmailID = StudentEmailID;
        }
        public int PStudentID
        {
            get
            {
                return this.StudentID;

            }
        }
        public string PStudentName
        {
            get
            {
                return this.StudentName;
            }
        }
        public string PStudentEmailID
        {
            get
            {
                return this.StudentEmailID;
            }
        }
        public void RequestLeave(string Leaveson)//event firing
        {
            Console.WriteLine("Student Request for  a leave :" + Leaveson);
            if(this.evtleave!=null)
            {
                this.evtleave(this.StudentID, Leaveson);
            }
        }
    }
}
