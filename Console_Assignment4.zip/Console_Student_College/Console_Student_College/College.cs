﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Student_College
{
    class College
    {
        public void LeaveNotify(int studentid,string reason)
        {
            Console.WriteLine("College Portal : Student is on leave,ID:"
                + studentid + ",Reason:" + reason);
        }

        private int CollegeID;
        private string CollegeName;

        private List<Student> studentlist = new List<Student>();
        public  College(int CollegeID,string CollegeName)
        {
            this.CollegeID = CollegeID;
            this.CollegeName = CollegeName;
        }
        public int PCollegeID
        {
            get
            {
                return this.CollegeID;
            }
        }
        public string PCollegeName
        {
            get
            {
                return this.CollegeName;
            }
        }
        public void AddStudent(Student obj)
        {
            this.studentlist.Add(obj);
            obj.evtleave += new Student.delleave(this.LeaveNotify);//Binding
        }
        public Student FindStudent(int id)
        {
            foreach(Student s in studentlist)
            {
                if(s.PStudentID==id)
                {
                    return s;
                }
            }
            return null;
        }
        public bool Remove(int id)
        {
            foreach(Student s in studentlist)
            {
                if(s.PStudentID==id)
                {
                    this.studentlist.Remove(s);
                    return true;
                }
            }
            return false;
        }
        public void ShowAll()
        {
            foreach(Student s in this.studentlist)
            {
                Console.WriteLine("Studet ID:" + s.PStudentID);
                Console.WriteLine("Student name:" + s.PStudentName);
            }
        }
    }
}
