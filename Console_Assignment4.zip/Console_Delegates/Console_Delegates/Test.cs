﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Test
    {
        public delegate void del(string str);//type to hold function d

        public void call(string str)
        {
            Console.WriteLine("Call :" + str);

        }
        public void getdata(string s)
        {
            Console.WriteLine("getdata:" + s);
        }
    }
}
