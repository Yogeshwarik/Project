﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Delegates
{
    class Program
    {
        public static void getinfo(string s)
        {
            Console.WriteLine("static Function:" + s);
        }
        static void Main(string[] args)
        {
            Test obj = new Test();
            Test.del d = new Test.del(obj.call);//creating delegate variable(single cast)
            d += obj.getdata;//multi cast
            d -= obj.getdata;
            d += Program.getinfo;

            d += delegate (string s)//anonymus function
              {
                  Console.WriteLine("Anonymus Function :" + s);
              };
            d += (s) => Console.WriteLine("Lambda Expression:" + s);
            d("Hello");
            Console.ReadLine();
        }
    }
}
