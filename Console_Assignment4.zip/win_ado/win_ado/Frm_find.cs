﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class Frm_find : Form
    {
        public Frm_find()
        {
            InitializeComponent();
        }

        private void Frm_find_Load(object sender, EventArgs e)
        {
            ddl_employeecities.Items.Add("BGL");
            ddl_employeecities.Items.Add("Chennai");
            ddl_employeecities.Items.Add("Mumbai");
        }

        private void btn_update_Click(object sender, EventArgs e)
        {

        }

        private void btn_find_Click(object sender, EventArgs e)
        {
            if (txt_employeeid.Text == string.Empty)
            {
                lbl_employeestatus.Text = "enter the employee ID";
            }
            else
            {
                int id = Convert.ToInt32(txt_employeeid.Text);
                EmployeesDAL dal = new EmployeesDAL();
                EmployeeModel model = dal.Find(id);
                if (model != null)
                {
                    txt_employeename.Text = model.EmployeeName;
                    txt_employeesalary.Text = model.Employeesalary.ToString();
                    ddl_employeecities.Text = model.EmployeeCity;
                    txt_employeedoj.Text = model.EmployeeDOJ.ToString();
                }
                else
                {
                    lbl_employeestatus.Text = "employee not found";
                }
            }
        }
    }
    }
}
