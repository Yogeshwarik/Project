﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if (txt_loginid.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter Login ID";
            }
           else if (txt_password.Text == string.Empty)
            {
                lbl_loginstatus.Text = "Enter Password";
            }
            else
            {
                int loginid =Convert.ToInt32(txt_loginid.Text);
                string password = txt_password.Text;
                EmployeesDAL dal = new EmployeesDAL();
                bool status = dal.Login(loginid, password);
                if(status==true)
                {
                    Frm_home obj = new Frm_home();
                    obj.Show();
                 
                     
                }
                else
                {
                    lbl_loginstatus.Text = "Invalid User ID or password";
                }
            }
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            frm_newuser obj = new frm_newuser();
            obj.Show();
        }
    }
}
