﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class frm_newuser : Form
    {
        public frm_newuser()
        {
            InitializeComponent();
        }

        private void frm_newuser_Load(object sender, EventArgs e)
        {
            ddl_employeecities.Items.Add("BGL");
            ddl_employeecities.Items.Add("Chennai");
            ddl_employeecities.Items.Add("Mumbai");
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if(txt_employeename.Text==string.Empty)
            {
                lbl_status.Text = "Enter Employee Name";

            }
            else if(txt_employeepassword.Text==string.Empty)
            {
                lbl_status.Text = "Enter Employee Password";
            }
            else if(ddl_employeecities.Text==string.Empty)
            {
                lbl_status.Text = "Select City";
            }
            else if(txt_employeesalary.Text==string.Empty)
            {
                lbl_status.Text = "Enter Salary";
            }
            else
            {
                EmployeeModel model = new EmployeeModel();
                model.EmployeeName = txt_employeename.Text;
                model.EmployeePassword = txt_employeepassword.Text;
                model.EmployeeCity = ddl_employeecities.Text;
                model.Employeesalary = Convert.ToInt32(txt_employeesalary.Text);
                EmployeesDAL dal = new EmployeesDAL();
                int id = dal.AddEmployee(model);
                lbl_status.Text="Employee Added,ID:"+id;
            }
        }
    }
}
