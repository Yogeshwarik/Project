﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_ado
{
    public partial class Frm_search : Form
    {
        public Frm_search()
        {
            InitializeComponent();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            EmployeesDAL dal = new EmployeesDAL();
            string key = txt_key.Text;
            List<EmployeeModel> list = dal.search(key);
            dg_employeesname.DataSource = list;
        }
    }
}
