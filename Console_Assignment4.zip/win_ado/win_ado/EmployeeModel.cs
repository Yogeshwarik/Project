﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace win_ado
{
    class EmployeeModel
    {
        public int EmployeeID { get; set; }
        public string EmployeeName { get; set; }
        public string EmployeePassword { get; set; }
        public string EmployeeCity { get; set; }
        public int Employeesalary { get; set; }
        public DateTime EmployeeDOJ { get; set; }

    }
}
