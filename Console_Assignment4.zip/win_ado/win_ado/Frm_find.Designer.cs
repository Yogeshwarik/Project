﻿namespace win_ado
{
    partial class Frm_find
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeeid = new System.Windows.Forms.Label();
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeesalary = new System.Windows.Forms.Label();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.txt_employeeid = new System.Windows.Forms.TextBox();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.ddl_employeecities = new System.Windows.Forms.ComboBox();
            this.txt_employeesalary = new System.Windows.Forms.TextBox();
            this.btn_find = new System.Windows.Forms.Button();
            this.lbl_employeestatus = new System.Windows.Forms.Label();
            this.lbl_employeedoj = new System.Windows.Forms.Label();
            this.txt_employeedoj = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lbl_employeeid
            // 
            this.lbl_employeeid.AutoSize = true;
            this.lbl_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeeid.Location = new System.Drawing.Point(70, 28);
            this.lbl_employeeid.Name = "lbl_employeeid";
            this.lbl_employeeid.Size = new System.Drawing.Size(145, 25);
            this.lbl_employeeid.TabIndex = 0;
            this.lbl_employeeid.Text = "Employee ID :";
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeename.Location = new System.Drawing.Point(70, 73);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(181, 25);
            this.lbl_employeename.TabIndex = 1;
            this.lbl_employeename.Text = "Employee Name :";
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(70, 130);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(162, 25);
            this.lbl_employeecity.TabIndex = 2;
            this.lbl_employeecity.Text = "Employee City :";
            // 
            // lbl_employeesalary
            // 
            this.lbl_employeesalary.AutoSize = true;
            this.lbl_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeesalary.Location = new System.Drawing.Point(70, 194);
            this.lbl_employeesalary.Name = "lbl_employeesalary";
            this.lbl_employeesalary.Size = new System.Drawing.Size(186, 25);
            this.lbl_employeesalary.TabIndex = 3;
            this.lbl_employeesalary.Text = "Employee Salary :";
            // 
            // btn_update
            // 
            this.btn_update.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_update.Location = new System.Drawing.Point(98, 308);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(142, 45);
            this.btn_update.TabIndex = 4;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.Location = new System.Drawing.Point(365, 308);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(219, 45);
            this.btn_delete.TabIndex = 5;
            this.btn_delete.Text = "Delete Employee";
            this.btn_delete.UseVisualStyleBackColor = true;
            // 
            // txt_employeeid
            // 
            this.txt_employeeid.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeeid.Location = new System.Drawing.Point(294, 25);
            this.txt_employeeid.Name = "txt_employeeid";
            this.txt_employeeid.Size = new System.Drawing.Size(165, 31);
            this.txt_employeeid.TabIndex = 6;
            // 
            // txt_employeename
            // 
            this.txt_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeename.Location = new System.Drawing.Point(294, 73);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(165, 31);
            this.txt_employeename.TabIndex = 7;
            // 
            // ddl_employeecities
            // 
            this.ddl_employeecities.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_employeecities.FormattingEnabled = true;
            this.ddl_employeecities.Location = new System.Drawing.Point(294, 130);
            this.ddl_employeecities.Name = "ddl_employeecities";
            this.ddl_employeecities.Size = new System.Drawing.Size(165, 33);
            this.ddl_employeecities.TabIndex = 8;
            // 
            // txt_employeesalary
            // 
            this.txt_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeesalary.Location = new System.Drawing.Point(294, 191);
            this.txt_employeesalary.Name = "txt_employeesalary";
            this.txt_employeesalary.Size = new System.Drawing.Size(165, 31);
            this.txt_employeesalary.TabIndex = 9;
            // 
            // btn_find
            // 
            this.btn_find.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_find.Location = new System.Drawing.Point(537, 25);
            this.btn_find.Name = "btn_find";
            this.btn_find.Size = new System.Drawing.Size(184, 59);
            this.btn_find.TabIndex = 10;
            this.btn_find.Text = "Find Employee";
            this.btn_find.UseVisualStyleBackColor = true;
            this.btn_find.Click += new System.EventHandler(this.btn_find_Click);
            // 
            // lbl_employeestatus
            // 
            this.lbl_employeestatus.AutoSize = true;
            this.lbl_employeestatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeestatus.ForeColor = System.Drawing.Color.Red;
            this.lbl_employeestatus.Location = new System.Drawing.Point(93, 380);
            this.lbl_employeestatus.Name = "lbl_employeestatus";
            this.lbl_employeestatus.Size = new System.Drawing.Size(174, 25);
            this.lbl_employeestatus.TabIndex = 11;
            this.lbl_employeestatus.Text = "Employee Status";
            // 
            // lbl_employeedoj
            // 
            this.lbl_employeedoj.AutoSize = true;
            this.lbl_employeedoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeedoj.Location = new System.Drawing.Point(70, 245);
            this.lbl_employeedoj.Name = "lbl_employeedoj";
            this.lbl_employeedoj.Size = new System.Drawing.Size(161, 25);
            this.lbl_employeedoj.TabIndex = 12;
            this.lbl_employeedoj.Text = "EmployeeDOJ :";
            // 
            // txt_employeedoj
            // 
            this.txt_employeedoj.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeedoj.Location = new System.Drawing.Point(294, 245);
            this.txt_employeedoj.Name = "txt_employeedoj";
            this.txt_employeedoj.Size = new System.Drawing.Size(165, 31);
            this.txt_employeedoj.TabIndex = 13;
            // 
            // Frm_find
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(874, 470);
            this.Controls.Add(this.txt_employeedoj);
            this.Controls.Add(this.lbl_employeedoj);
            this.Controls.Add(this.lbl_employeestatus);
            this.Controls.Add(this.btn_find);
            this.Controls.Add(this.txt_employeesalary);
            this.Controls.Add(this.ddl_employeecities);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.txt_employeeid);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.lbl_employeesalary);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employeename);
            this.Controls.Add(this.lbl_employeeid);
            this.Name = "Frm_find";
            this.Text = "Frm_find";
            this.Load += new System.EventHandler(this.Frm_find_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeeid;
        private System.Windows.Forms.Label lbl_employeename;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeesalary;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox txt_employeeid;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.ComboBox ddl_employeecities;
        private System.Windows.Forms.TextBox txt_employeesalary;
        private System.Windows.Forms.Button btn_find;
        private System.Windows.Forms.Label lbl_employeestatus;
        private System.Windows.Forms.Label lbl_employeedoj;
        private System.Windows.Forms.TextBox txt_employeedoj;
    }
}