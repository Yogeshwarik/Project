﻿namespace win_ado
{
    partial class Frm_search
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_key = new System.Windows.Forms.TextBox();
            this.lbl_enterkey = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.dg_employeesname = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dg_employeesname)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_key
            // 
            this.txt_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_key.Location = new System.Drawing.Point(185, 92);
            this.txt_key.Name = "txt_key";
            this.txt_key.Size = new System.Drawing.Size(148, 29);
            this.txt_key.TabIndex = 9;
            // 
            // lbl_enterkey
            // 
            this.lbl_enterkey.AutoSize = true;
            this.lbl_enterkey.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_enterkey.Location = new System.Drawing.Point(29, 86);
            this.lbl_enterkey.Name = "lbl_enterkey";
            this.lbl_enterkey.Size = new System.Drawing.Size(97, 24);
            this.lbl_enterkey.TabIndex = 8;
            this.lbl_enterkey.Text = "Enter Key:";
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_search.Location = new System.Drawing.Point(407, 84);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(175, 46);
            this.btn_search.TabIndex = 16;
            this.btn_search.Text = "Search Employee";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // dg_employeesname
            // 
            this.dg_employeesname.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_employeesname.Location = new System.Drawing.Point(221, 224);
            this.dg_employeesname.Name = "dg_employeesname";
            this.dg_employeesname.Size = new System.Drawing.Size(445, 150);
            this.dg_employeesname.TabIndex = 17;
            // 
            // Frm_search
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(747, 414);
            this.Controls.Add(this.dg_employeesname);
            this.Controls.Add(this.btn_search);
            this.Controls.Add(this.txt_key);
            this.Controls.Add(this.lbl_enterkey);
            this.Name = "Frm_search";
            this.Text = "Frm_search";
            ((System.ComponentModel.ISupportInitialize)(this.dg_employeesname)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_key;
        private System.Windows.Forms.Label lbl_enterkey;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.DataGridView dg_employeesname;
    }
}