﻿namespace win_ado
{
    partial class frm_newuser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_employeename = new System.Windows.Forms.Label();
            this.lbl_employeepassword = new System.Windows.Forms.Label();
            this.lbl_employeecity = new System.Windows.Forms.Label();
            this.lbl_employeesalary = new System.Windows.Forms.Label();
            this.txt_employeename = new System.Windows.Forms.TextBox();
            this.txt_employeepassword = new System.Windows.Forms.TextBox();
            this.ddl_employeecities = new System.Windows.Forms.ComboBox();
            this.txt_employeesalary = new System.Windows.Forms.TextBox();
            this.btn_newuser = new System.Windows.Forms.Button();
            this.lbl_status = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_employeename
            // 
            this.lbl_employeename.AutoSize = true;
            this.lbl_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeename.Location = new System.Drawing.Point(100, 64);
            this.lbl_employeename.Name = "lbl_employeename";
            this.lbl_employeename.Size = new System.Drawing.Size(162, 24);
            this.lbl_employeename.TabIndex = 0;
            this.lbl_employeename.Text = "Employee Name :";
            // 
            // lbl_employeepassword
            // 
            this.lbl_employeepassword.AutoSize = true;
            this.lbl_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeepassword.Location = new System.Drawing.Point(100, 126);
            this.lbl_employeepassword.Name = "lbl_employeepassword";
            this.lbl_employeepassword.Size = new System.Drawing.Size(193, 24);
            this.lbl_employeepassword.TabIndex = 1;
            this.lbl_employeepassword.Text = "Employee Password :";
            // 
            // lbl_employeecity
            // 
            this.lbl_employeecity.AutoSize = true;
            this.lbl_employeecity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeecity.Location = new System.Drawing.Point(100, 189);
            this.lbl_employeecity.Name = "lbl_employeecity";
            this.lbl_employeecity.Size = new System.Drawing.Size(141, 24);
            this.lbl_employeecity.TabIndex = 2;
            this.lbl_employeecity.Text = "Employee City :";
            // 
            // lbl_employeesalary
            // 
            this.lbl_employeesalary.AutoSize = true;
            this.lbl_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_employeesalary.Location = new System.Drawing.Point(100, 244);
            this.lbl_employeesalary.Name = "lbl_employeesalary";
            this.lbl_employeesalary.Size = new System.Drawing.Size(162, 24);
            this.lbl_employeesalary.TabIndex = 3;
            this.lbl_employeesalary.Text = "Employee Salary :";
            // 
            // txt_employeename
            // 
            this.txt_employeename.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeename.Location = new System.Drawing.Point(335, 64);
            this.txt_employeename.Name = "txt_employeename";
            this.txt_employeename.Size = new System.Drawing.Size(248, 29);
            this.txt_employeename.TabIndex = 4;
            // 
            // txt_employeepassword
            // 
            this.txt_employeepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeepassword.Location = new System.Drawing.Point(335, 123);
            this.txt_employeepassword.Name = "txt_employeepassword";
            this.txt_employeepassword.Size = new System.Drawing.Size(248, 29);
            this.txt_employeepassword.TabIndex = 5;
            // 
            // ddl_employeecities
            // 
            this.ddl_employeecities.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddl_employeecities.FormattingEnabled = true;
            this.ddl_employeecities.Location = new System.Drawing.Point(335, 189);
            this.ddl_employeecities.Name = "ddl_employeecities";
            this.ddl_employeecities.Size = new System.Drawing.Size(248, 32);
            this.ddl_employeecities.TabIndex = 6;
            // 
            // txt_employeesalary
            // 
            this.txt_employeesalary.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_employeesalary.Location = new System.Drawing.Point(335, 244);
            this.txt_employeesalary.Name = "txt_employeesalary";
            this.txt_employeesalary.Size = new System.Drawing.Size(248, 29);
            this.txt_employeesalary.TabIndex = 7;
            // 
            // btn_newuser
            // 
            this.btn_newuser.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newuser.Location = new System.Drawing.Point(104, 308);
            this.btn_newuser.Name = "btn_newuser";
            this.btn_newuser.Size = new System.Drawing.Size(236, 41);
            this.btn_newuser.TabIndex = 8;
            this.btn_newuser.Text = "New User";
            this.btn_newuser.UseVisualStyleBackColor = true;
            this.btn_newuser.Click += new System.EventHandler(this.btn_newuser_Click);
            // 
            // lbl_status
            // 
            this.lbl_status.AutoSize = true;
            this.lbl_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_status.ForeColor = System.Drawing.Color.Red;
            this.lbl_status.Location = new System.Drawing.Point(100, 383);
            this.lbl_status.Name = "lbl_status";
            this.lbl_status.Size = new System.Drawing.Size(128, 24);
            this.lbl_status.TabIndex = 9;
            this.lbl_status.Text = "Employee ID :";
            // 
            // frm_newuser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(765, 459);
            this.Controls.Add(this.lbl_status);
            this.Controls.Add(this.btn_newuser);
            this.Controls.Add(this.txt_employeesalary);
            this.Controls.Add(this.ddl_employeecities);
            this.Controls.Add(this.txt_employeepassword);
            this.Controls.Add(this.txt_employeename);
            this.Controls.Add(this.lbl_employeesalary);
            this.Controls.Add(this.lbl_employeecity);
            this.Controls.Add(this.lbl_employeepassword);
            this.Controls.Add(this.lbl_employeename);
            this.Name = "frm_newuser";
            this.Text = "frm_newuser";
            this.Load += new System.EventHandler(this.frm_newuser_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_employeename;
        private System.Windows.Forms.Label lbl_employeepassword;
        private System.Windows.Forms.Label lbl_employeecity;
        private System.Windows.Forms.Label lbl_employeesalary;
        private System.Windows.Forms.TextBox txt_employeename;
        private System.Windows.Forms.TextBox txt_employeepassword;
        private System.Windows.Forms.ComboBox ddl_employeecities;
        private System.Windows.Forms.TextBox txt_employeesalary;
        private System.Windows.Forms.Button btn_newuser;
        private System.Windows.Forms.Label lbl_status;
    }
}