﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Jagged_Array_Enum_Var_Dynamic
{
    class Program
    {
        static void Main(string[] args)
        {

            string s = "20000899999";
            long x = Convert.ToInt64(s);

            int a = 99;
            long b = a;
          //  b = 46642642;
            Console.WriteLine(b);
            a = Convert.ToInt32(b);



            Test t = new Test();

            t.i = 200;
            Console.WriteLine(t.i);
            t.i = null;
            Console.WriteLine(t.i);
            Console.WriteLine(t.status);
            Console.WriteLine(t.name);



            /*
            dynamic d = 100;//run time
            string s2 = d.ToString();

            var i1 = 100;//compile time

            string s1 = i1.ToString();

            i1 = 200;

            var str="ABC";*/





            /*
            PaymentType p = PaymentType.NetBanking;

            Console.WriteLine(p);
            Console.WriteLine(Convert.ToInt32(p));

            //int[][] jagged = new int[3][];

            //jagged[0] = new int[3];
            //jagged[1] = new int[2];
            //jagged[2] = new int[4];

            //jagged[0][0] = 20;
            //jagged[0][1] = 33;
            //jagged[0][2] = 66;

            //jagged[1][0] = 77;
            //jagged[1][1] = 45;

            //jagged[2][0] = 87;
            //jagged[2][1] = 46;
            //jagged[2][2] = 73;
            //jagged[2][3] = 90;

            ////int x = jagged[1][1];
            ////Console.WriteLine(x);
            //for(int i=0;i<jagged.Length;i++)
            //{
            //    for(int j=0;j<jagged[i].Length;j++)
            //    {
            //        Console.WriteLine(jagged[i][j]);
            //    }
            //}*/

            Console.ReadLine();
        }
    }
}
