﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Jagged_Array_Enum_Var_Dynamic
{
    class Test
    {
        public int x;//Default 0,can not allow null
        //Nullable 
        public int? i;//Default Null,allow null value



        public bool? status;//false
        public string name;//null

    }
}
