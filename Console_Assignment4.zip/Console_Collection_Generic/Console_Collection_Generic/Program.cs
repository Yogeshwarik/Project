﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Collection_Generic
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, string> names = new Dictionary<int, string>();
            names.Add(1, "John");
            names.Add(2, "Peter");
            names.Add(3, "David");
            names.Add(100, "Rosy");


            foreach(KeyValuePair<int,string> kv in names)
            {
                Console.WriteLine(kv.Key + " " + kv.Value);
            }
            foreach(string v in names.Values)
            {
                Console.WriteLine(v);
            }
            foreach(int k in names.Keys)
            {
                Console.WriteLine(k);
            }
            string s1 = names[100];
            Console.WriteLine(s1);

            names.Remove(4);
            

            if(names.ContainsKey(77))
            {
                string s = names[77];
                Console.WriteLine(s);
            }


            /*
            List<int> marks = new List<int>();
            marks.Add(88);//0
            marks.Add(77);//1
            marks.Add(33);//2
            marks.Add(44);//3
            marks.Add(67);//4

            for(int c=0;c<marks.Count;c++)
            {
                int i = marks[c];
                Console.WriteLine(i);
            }

            marks.Remove(33);
            marks[1] = 99;
            marks.Sort();
            marks.Reverse();


            foreach(int m in marks)
            {
                Console.WriteLine(m);
            }*/
            

            /*
            Test obj = new Test();
            int x = obj.Call<int>(100);

            Console.WriteLine(x);*/

            Console.ReadLine();


       }
    }
}
