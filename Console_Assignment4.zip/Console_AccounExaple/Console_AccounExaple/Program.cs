﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AccounExaple
{
    class Program
    {
        static void Main(string[] args)
        {
            Account acc = new Account(11, "ABC", 5000);

            int id = acc.GetAccountID();
            string name = acc.GetCustomername();
            int balance = acc.GetAccountBalance();

            Console.WriteLine("Accont number :" + id);
            Console.WriteLine("Customer name:" + name);
            Console.WriteLine("Balance:" + balance);

            acc.Deposite(2000);
            balance = acc.GetAccountBalance();

            Console.WriteLine("Deposite amount:" + balance);

            acc.Withdraw(1000);
            balance = acc.GetAccountBalance();

            Console.WriteLine("Withdraw amount: " + balance);

            Console.ReadLine();
        }
    }
}
