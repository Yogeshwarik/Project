﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AccounExaple
{
    class Account
    {
        int AccountID;
        string CustomerName;
        int AccountBalance;

        public Account(int AccountID,string CustomerName,int AccountBalance)
        {
            this.AccountID = AccountID;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;

        }
        public int GetAccountID()
        {
            return this.AccountID;
        }
        public string GetCustomername()
        {
            return this.CustomerName;
        }
        public int GetAccountBalance()
        {
            return this.AccountBalance;
        }
        public void Deposite(int d)
        {
            AccountBalance = AccountBalance + d;
        }
        public void Withdraw(int w)
        {
            AccountBalance = AccountBalance - w;
        }
    }
}
