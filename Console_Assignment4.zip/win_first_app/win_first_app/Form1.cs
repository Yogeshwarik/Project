﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_first_app
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            if(txt_loginid.Text==string.Empty)
            {
                MessageBox.Show("Enter Your Login ID");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Your Password");
            }
            else
            {
                string loginid = txt_loginid.Text;
                string password = txt_password.Text;
                if(loginid=="user1" && password=="pass@123")
                {
                    MessageBox.Show("Valid User");
                    frm_home obj = new frm_home();
                    obj.Show();
                }
                else
                {
                    MessageBox.Show("Invalid User");
                }
            }
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            frm_newuser obj = new frm_newuser();
            obj.Show();
        }
    }
}
