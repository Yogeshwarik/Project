﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace win_first_app
{
    public partial class frm_newuser : Form
    {
        public frm_newuser()
        {
            InitializeComponent();
        }

        private void frm_newuser_Load(object sender, EventArgs e)
        {
            ddl_cities.Items.Add("BGL");
            ddl_cities.Items.Add("Chennai");
            ddl_cities.Items.Add("Mumbai");
            ddl_cities.Items.Add("Pune");
        }

        private void btn_newuser_Click(object sender, EventArgs e)
        {
            if(txt_name.Text==string.Empty)
            {
                MessageBox.Show("Enter Name");

            }
            else if(txt_emailid.Text==string.Empty)
            {
                MessageBox.Show("Enter Email");

            }
            else if(ddl_cities.Text==string.Empty)
            {
                MessageBox.Show("Select a City");
            }
            else if(rdb_male.Checked==false && rdb_female.Checked==false)
            {
                MessageBox.Show("Select Gender");
            }
            else if(txt_password.Text==string.Empty)
            {
                MessageBox.Show("Enter Password");
            }
            else
            {
                string name = txt_name.Text;
                string emailid = txt_emailid.Text;
                string city = ddl_cities.Text;
                string gender = string.Empty;
                if(rdb_male.Checked==true)
                {
                    gender = "Male";
                }
                else
                {
                    gender = "Female";
                }
                string password = txt_password.Text;
                //Database etc
                MessageBox.Show("User Created...");
            }
        }
    }
}
