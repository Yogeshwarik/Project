﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractPractice
{
    class Current :Account
    {
        public Current(string CustomerName,int AccountBalance)
            :base(CustomerName,AccountBalance)
        {
            Console.WriteLine("Current object constructoe");
        }

        public override void Deposite(int Amt)
        {
            this.AccountBalance = AccountBalance + Amt;
        }

        public override void Withdraw(int Amt)
        {
            this.AccountBalance = AccountBalance - Amt;
        }
    }
}
