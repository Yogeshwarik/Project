﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractPractice
{
    abstract class Account
    {
        private int AccountID;
        private string CustomerName;
        protected int AccountBalance;
        private static int Count = 100;

        public Account(string CustomerName,int AccountBalance)
        {
            this.AccountID = ++Account.Count;
            this.CustomerName = CustomerName;
            this.AccountBalance = AccountBalance;
        }
        public int PAccountID
        {
            get
            {
                return this.AccountID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public void StopPayment(int CheqeNo)
        {
            Console.WriteLine("Payment is stopped ,ref cheqe no:" + CheqeNo);
        }
        public int GetBalance()
        {
             return this.AccountBalance;
        }
        public abstract void Deposite(int Amt);
        public abstract void Withdraw(int Amt);
    }
}
