﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Order
    {
        public void AddProduct(IProduct p)
        {
            int price = p.GetProductPrice();
            string name = p.GetProductName();
            int id = p.GetProductID();
            Console.WriteLine("Product ID:" + id);
            Console.WriteLine("Product Name:" + name);
            Console.WriteLine("Product Price:" + price);
        }
    }
}
