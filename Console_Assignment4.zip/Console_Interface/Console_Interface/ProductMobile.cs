﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class ProductMobile :IProduct,IProductTesting
    {
        private int MobileID;
        private string MobileName;
        private int MobilePrice;
        private string MobileCompany;

        public ProductMobile(int MobileID,string MobileName,int MobilePrice,string MobileCompany)
        {
            this.MobileID = MobileID;
            this.MobileName = MobileName;
            this.MobilePrice = MobilePrice;
            this.MobileCompany = MobileCompany;
        }
        public void Start()
        {
            Console.WriteLine("Mobile Started");

        }
        public void Stop()
        {
            Console.WriteLine("Mobili Stopped");
        }

        public int GetProductPrice()
        {
            return this.MobilePrice;
        }

        public string GetProductName()
        {
            return this.MobileName;
        }

        public int GetProductID()
        {
            return this.MobileID;
        }
    }
}
