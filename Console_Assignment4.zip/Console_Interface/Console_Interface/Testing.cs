﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Interface
{
    class Testing
    {
        public void AddProduct(IProductTesting p)
        {
            int id = p.GetProductID();
            Console.WriteLine("Testing Dept ,Product ID :" + id);

            p.Start();
            p.Stop();
        }
    }
}
