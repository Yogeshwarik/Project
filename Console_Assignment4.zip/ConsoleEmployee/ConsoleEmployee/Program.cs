﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleEmployee
{
    class Program
    {
        static void Main(string[] args)
        {
            Company c = new Company("IBM", "BGL");
            Console.WriteLine("Company Name :" + c.PCompanyName);
            Console.WriteLine("Company Address :" + c.PCompanyAddress);

            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1.Add,2.Search,3.Remove,4.Show ,5.Request to Leave,6.Exit");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1:
                        {
                            Console.WriteLine("Enter the Emloyee Name");
                            string name = Console.ReadLine();

                            Console.WriteLine("Enter the Employee City");
                            string city = Console.ReadLine();

                            Employee e = new Employee(name, city);
                            c.AddEmployee(e);

                            Console.WriteLine("Employee Added :" + e.PEmployeeID);

                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("Enter the Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e = c.SearchEmployee(id);
                            if(e!=null)
                            {
                                Console.WriteLine("Employee ID : "+e.PEmployeeID);
                                Console.WriteLine("Employee Name : " + e.PEmployeeName);
                                Console.WriteLine("Employee City : " + e.PEmployeeCity);

                            }
                            else
                            {
                                Console.WriteLine("Employee not Found");
                            }
                           
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("Enter the Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                             
                            bool status = c.RemoveEmployee(id);
                            if (status== true)
                            {
                                Console.WriteLine("Remove Successfully");


                            }
                            else
                            {
                                Console.WriteLine("Not Found");
                            }

                            break;
                        }
                    case 4:
                        {
                            c.ShowEmployee()
                                break;
                        }
                    case 5:
                        {
                            Console.WriteLine("Enter the Employee ID");
                            int id = Convert.ToInt32(Console.ReadLine());
                            Employee e = c.SearchEmployee(id);

                            Console.WriteLine("Enter the Reason to leave");
                            string reason = Console.ReadLine();

                            e.RequestLeave(reason);
             

                            break;
                        }
                }
            }
        }
    }
}
