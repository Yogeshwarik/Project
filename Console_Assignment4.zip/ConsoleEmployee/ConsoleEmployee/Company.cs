﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleEmployee
{
    class Company
    {
        private string CompanyName;
        private string CompanyAddress;
        private List<Employee> employeelist = new List<Employee>();
        public Company(string CompanyName,string CompanyAddress)
        {
            this.CompanyName = CompanyName;
            this.CompanyAddress = CompanyAddress;
        }
        public string PCompanyName
        {
            get
            {
                return this.CompanyName;
            }
        }
        public string PCompanyAddress
        {
            get
            {
                return this.CompanyAddress;
            }
        }
        public void AddEmployee(Employee emp)
        {
            foreach(Employee e in employeelist)
            {
                 this.employeelist.Add(e);
            }
        }
        public Employee SearchEmployee(int EmpID)
        {
            foreach(Employee e in employeelist)
            {
                if(e.PEmployeeID==EmpID)
                {
                    return e;
                }
            }
            return null;
        }
        public bool RemoveEmployee(int EmpID)
        {
            foreach(Employee e in employeelist)
            {
                if(e.PEmployeeID==EmpID)
                {
                    this.employeelist.Remove(e);
                    return true;
                }
            }
            return false;
        }
        public void ShowEmployee()
        {
            foreach (Employee e in employeelist)
            {
                Console.WriteLine("Employee ID:" + e.PEmployeeID);
                Console.WriteLine("Employee Name:" + e.PEmployeeName);
                Console.WriteLine("Employee City:" + e.PEmployeeCity);
            }
        }
    }
}
