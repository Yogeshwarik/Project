﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment5
{
    class Order
    {
        private int OrderID;
        private string CustomerName;
        private string ItemName;
        private int ItemQuantity;
        private int ItemPrice;

        public Order(int OrderID,string CustomerName,string ItemName,int ItemQuantity,
            int ItemPrice)
        {
            this.OrderID = OrderID;
            this.CustomerName = CustomerName;
            this.ItemName = ItemName;
            this.ItemQuantity = ItemQuantity;
            this.ItemPrice = ItemPrice;

        }
        public int GetOderID()
        {
            return this.OrderID;
        }
        public string GetCustomerName()
        {
            return this.CustomerName;
        }
        public string GetItemName()
        {
            return this.ItemName;
        }
        public int GetItemQuantity()
        {
            return this.ItemQuantity;
        }
        public int GetItemPrice()
        {
            return this.ItemPrice;
        }
        public int GetOrderAmount()
        {
            int total=ItemQuantity * ItemPrice;
            return total;
        }
        public void UpdateItemQuantity(int quantity)
        {
            this.ItemQuantity = quantity;
        }

    }
}
