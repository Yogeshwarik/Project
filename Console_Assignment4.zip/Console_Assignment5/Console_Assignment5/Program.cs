﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment5
{
    class Program
    {
        static void Main(string[] args)
        {
            Order obj1 = new Order(11, "Yogi", "LAPTOP", 2, 10);

            int id = obj1.GetOderID();
            string name = obj1.GetCustomerName();
            string itemname = obj1.GetItemName();
            int quantity = obj1.GetItemQuantity();
            int price = obj1.GetItemPrice();

            Console.WriteLine("**************OREDER ITEMS*************");
            Console.WriteLine("Item ID :" + id);
            Console.WriteLine("Customer Name :" + name);
            Console.WriteLine("Item Name:" + itemname);
            Console.WriteLine("Item quantity:" + quantity);
            Console.WriteLine("Item price :" + price);

            Console.WriteLine("***********ODER AMOUNT***************");
            int total=obj1.GetOrderAmount();
            Console.WriteLine("order Amount:" + total);

            Console.WriteLine("**********UPDATED ITEM QUANTITY*********");
            obj1.UpdateItemQuantity(4);
            quantity = obj1.GetItemQuantity();

            Console.WriteLine("Item Quantity :" + quantity);

            Console.ReadLine();


        }
    }
}
