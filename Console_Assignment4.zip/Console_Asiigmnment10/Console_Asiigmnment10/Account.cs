﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Asiigmnment10
{
    class Account
    {
        public void GetEmployee(IAccountEmp a)
        {
            int salary = a.GetEmployeeSalary();
            int accno = a.GetEmployeeAccNo();
            int id = a.GetEmployeeID();
            Console.WriteLine("---------IAccountEmp---------------");
            Console.WriteLine("Salary :" + salary);
            Console.WriteLine("Accono :" + accno);
            Console.WriteLine("ID:" + id);
        }
    }
}
