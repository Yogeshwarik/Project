﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Asiigmnment10
{
    class Manager
    {
        public void GetEmployee(IManagerEmp m)
        {
            int id = m.GetEmployeeID();
            int exp = m.GetEmployeeExp();
            string deatils = m.GetEmployeeProjectDetails();

            Console.WriteLine("-----------IManagerEmp---------------");
            Console.WriteLine("Id:" + id);
            Console.WriteLine("Experiance:" + exp);
            Console.WriteLine("Project Details:" + deatils);
        }
    }
}
