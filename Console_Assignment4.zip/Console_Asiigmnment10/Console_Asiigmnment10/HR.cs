﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Asiigmnment10
{
    class HR
    {
        public void GetEmployee(IHREmp h)
        {
            int id = h.GetEmployeeID();
            string address = h.GetEmployeeAddress();
            int salary = h.GetEmployeeSalary();

            Console.WriteLine("---------------IHREmp------------------");
            Console.WriteLine("Id:" + id);
            Console.WriteLine("Address :" + address);
            Console.WriteLine("Salary:" + salary);
        }

       
    }
}
