﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Asiigmnment10
{
    class Employee :IHREmp,IAccountEmp,IManagerEmp
    {
        protected int EmployeeID;
        protected string EmployeeName;
        protected string EmployeeCity;
        protected int EmployeeSalary;
        protected string EmployeeAddress;
        protected string EmployeeProjectDetails;
        protected int EmployeeExp;
        protected int EmployeeAccNo;
        protected int EmployeeAccBalance;
        protected int EmployeeAge;

        public Employee(int EmployeeID,string EmployeeName,string EmployeeCity,int EmployeeSalary,string EmployeeAddress,
            string EmployeeProjectDetails,int EmployeeExp,int EmployeeAccNo,int EmployeeAccBalance,int EmployeeAge)
        {
            this.EmployeeID = EmployeeID;
            this.EmployeeName = EmployeeName;
            this.EmployeeCity = EmployeeCity;
            this.EmployeeSalary = EmployeeSalary;
            this.EmployeeAddress = EmployeeAddress;
            this.EmployeeProjectDetails = EmployeeProjectDetails;
            this.EmployeeExp = EmployeeExp;
            this.EmployeeAccNo = EmployeeAccNo;
            this.EmployeeAccBalance = EmployeeAccBalance;
            this.EmployeeAge = EmployeeAge;
        }
        public int GetEmployeeID()
        {
            return this.EmployeeID;
        }
        public string GetEmployeeName()
        {
            return this.EmployeeName;
        }
        public string GetEmployeeCity()
        {
            return this.EmployeeCity;
        }
        public int GetEmployeeSalary()
        {
            return this.EmployeeSalary;
        }
        public string GetEmployeeAddress()
        {
            return this.EmployeeAddress;

        }
        public string GetEmployeeProjectDetails()
        {
            return this.EmployeeProjectDetails;
        }
        public int GetEmployeeExp()
        {
            return this.EmployeeExp;

        }
        public int GetEmployeeAccNo()
        {
            return this.EmployeeAccNo;

        }
        public int GetEmployeeAccBalance()
        {
            return this.EmployeeAccBalance;

        }
        public int GetEmployeeAge()
        {
            return this.EmployeeAge;

        }

        
    }
}
