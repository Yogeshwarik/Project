﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Asiigmnment10
{
    class Program
    {
        static void Main(string[] args)
        {

            Employee emp = new Employee(123, "abc", "BGL", 50000,
                "Kamkshipalya", "C# project", 2, 111, 70000,22);

            HR r = new HR();
            r.GetEmployee(emp);

            Account acc = new Account();
            acc.GetEmployee(emp);

            Manager man = new Manager();
            man.GetEmployee(emp);

            
            Console.ReadLine();


        }
    }
}
