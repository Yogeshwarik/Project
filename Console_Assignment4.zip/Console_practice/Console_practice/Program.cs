﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_practice
{
    class Program
    {
        static void Main(string[] args)
        {
             //int[] marks = new int[5];
            /*marks[0] = 55;
            marks[1] = 44;
            marks[2] = 33;
            marks[3] = 22;
            marks[4] = 67;*/
            int[] marks = { 55, 44, 33, 22, 67 };
            int max = marks[0];
            int min = marks[1];
            for(int i=0;i<marks.Length;i++)
            {
                Console.WriteLine(marks[i]);
            }

            for (int j = 0; j < marks.Length; j++)
            {
                if (marks[j] > max)
                {
                    max = marks[j];
                }
                if (marks[j] < min)
                {
                    min = marks[j];
                }
            }
            Console.WriteLine("Max :" + max);
            Console.WriteLine("Min :" + min);

            int temp = marks[0];
            marks[0] = marks[marks.Length - 1];
            marks[marks.Length - 1] = temp;
            for(int c=0;c<marks.Length;c++)
            {
                Console.WriteLine(marks[c]);
            }

            Console.ReadLine();
        }
    }
}
