﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_DLL_Call
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter  No of Days");
            int noofdays = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter Per Day Salary");
            int perdaysalary = Convert.ToInt32(Console.ReadLine());

            TestLibrary.Test dll = new TestLibrary.Test();
            int salary = dll.GetSalary(perdaysalary, noofdays);
            Console.WriteLine("Salary:" + salary);

            Console.ReadLine();
        }
    }
}
