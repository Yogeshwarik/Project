﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Prime_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            //  int[] count = new int[10];
           
            int[] a = { 2, 3, 4, 5, 6, 8, 10 };
           
            for(int i=0;i<a.Length;i++)
            {
                Console.WriteLine(a[i]);
            }

            for (int i = 0; i < a.Length; i++)
            {
                int count = 0;
                int n = a[i];
                for (int k = 1; k <=n/2; k++)
                {
                    if (a[i] % k == 0)
                    {

                        count++;
                    }
                }
                    if (count==1)
                    {
                        Console.WriteLine("prime");
                    }
                    else
                     {
                    Console.WriteLine("not prime");
                     }
                

            }
            
               
            
            Console.ReadLine();

        }
    }
}
