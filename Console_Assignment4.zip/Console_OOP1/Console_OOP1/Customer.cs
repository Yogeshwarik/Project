﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Customer
    {
        private int CustomerID;
        private string CustomerName;
        private int CustomerAge;
        private string CustomerCity;

        public Customer(int CustomerID,string CustomerName,
            int CustomerAge,string CustomerCity)
        {
            this.CustomerID = CustomerID;
            this.CustomerName = CustomerName;
            this.CustomerAge = CustomerAge;
            this.CustomerCity = CustomerCity;

            Console.WriteLine("object constuctor called");
        }

        public string GetName()
        {
            return this.CustomerName;

        }
        public string Getcity()
        {
            return this.CustomerCity;
        }
        public int GetAge()
        {
            return this.CustomerAge;
        }
        public void UpadateAge(int Age)
        {
            this.CustomerAge = Age;
        }


    }
}
