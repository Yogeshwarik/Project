﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP1
{
    class Program
    {
        static void Main(string[] args)
        {
            Customer obj = new Customer(1, "ABC", 21, "BGL");
           
            string name = obj.GetName();
            string city = obj.Getcity();
            int age = obj.GetAge();

            Console.WriteLine("Name :" + name);
            Console.WriteLine("City :" + city);
            Console.WriteLine("Age:" + age);

            obj.UpadateAge(30);
            age = obj.GetAge();

            Console.WriteLine("Upadated Age :" + age.ToString());

            Console.ReadLine();
        }
    }
}
