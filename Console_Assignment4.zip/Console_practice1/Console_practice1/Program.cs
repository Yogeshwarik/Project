﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_practice1
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("-------Account Object1-----------");
            Account obj = new Account(1, "yogi", 6000);

            int id = obj.GetAccountID();
            string name = obj.GetCustomerName();
            int balance = obj.GetBalance();

            Console.WriteLine("Account number : " + id);
            Console.WriteLine("Customer Name : " + name);
            Console.WriteLine("Balance : " + balance);

            obj.deposite(2000);
            balance = obj.GetBalance();
            Console.WriteLine("Deposited successfully");
          
            
            
            obj.withdraw(1000);
            balance = obj.GetBalance();
            Console.WriteLine("Withdraw succeceded");

            Console.WriteLine("-------Account Object2-----------");
            Account obj1 = new Account(2, "Pooja", 8000);

            id = obj1.GetAccountID();
            name = obj1.GetCustomerName();
            balance = obj1.GetBalance();

            Console.WriteLine("Account number : " + id);
            Console.WriteLine("Customer Name : " + name);
            Console.WriteLine("Balance : " + balance);

            obj1.deposite(2000);
            balance = obj1.GetBalance();
            Console.WriteLine("Deposited successfully");

            obj1.withdraw(1000);
            balance = obj1.GetBalance();
            Console.WriteLine("Withdraw succeceded");

            Console.ReadLine();
        }
    }
}
