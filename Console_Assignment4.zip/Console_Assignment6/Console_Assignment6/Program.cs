﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment6
{
    class Program
    {
        static void Main(string[] args)
        {
            Order obj = new Order("ABC", "PEN", 10, 2);

            Console.WriteLine(obj.POrderID);
            Console.WriteLine(obj.PCustomerName);
            Console.WriteLine(obj.PItemName);
            Console.WriteLine(obj.PItemPrice);
            Console.WriteLine(obj.PItemQuantity);

            

            int total=obj.GetOrderAmount();
            Console.WriteLine(total);

            Console.WriteLine("updated Quantity");
            obj.PItemQuantity = 4;
            Console.WriteLine(obj.PItemQuantity);

            Console.WriteLine("Updated order amount");
            total = obj.GetOrderAmount();
            Console.WriteLine(total);




            Console.ReadLine();
            
        }
    }
}
