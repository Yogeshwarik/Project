﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {

            int balance=500,amt;
            Console.WriteLine("Enter the account number");
            int AccounId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the customer name");
            string Cname = Console.ReadLine();
            Console.WriteLine("enter the Address");
            string Address = Console.ReadLine();
            Console.WriteLine("enter the type of account");
            string saving = Console.ReadLine();
           // Console.WriteLine("balance is "+balance);
            bool flag = true;
            while(flag)
            {
                Console.WriteLine("1.Deposite,2.Withdraw,3.CheckBalance,4.Exit");
                Console.WriteLine("Enter the choice");
                int ch = Convert.ToInt32(Console.ReadLine());
                switch(ch)
                {
                    case 1:
                        {
                            Console.WriteLine("enter the amount to deposite");
                            amt= Convert.ToInt32(Console.ReadLine());
                            balance= balance+amt;
                            Console.WriteLine("Deposite Succefully");
                           // Console.WriteLine("total amount is:"+amt);
                            break;
                        }
                    case 2:
                        {
                            Console.WriteLine("enter the amount to withdraw");
                            amt = Convert.ToInt32(Console.ReadLine());
                            balance=balance-amt;
                            Console.WriteLine("Withdraw successfuly");
                            break;
                        }
                    case 3:
                        {
                            
                            //balance = Convert.ToInt32(Console.ReadLine());
                            Console.WriteLine("available balance is:" + balance);

                            break;
                        }
                    case 4:
                        {
                            flag = false;
                            break;

                        }
                    default:Console.WriteLine("Invalid choice");
                        {
                            break;
                        }
                        
                }
             
            }

            

          

        }
    }
}
