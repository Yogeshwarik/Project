﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractAssignment
{
    class Current :Account
    {
        public Current(string CustomerName,int Balance)
            :base(CustomerName,Balance)
        {
            Console.WriteLine("Currenrt object class");
        }

        public override void Deposite(int Amt)
        {
            Balance = Balance + Amt + 100;

        }

        public override void Withdraw(int Amt)
        {
            Balance = Balance - Amt - 10;
        }
    }
}
