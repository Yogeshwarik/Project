﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractAssignment
{
    class Saving :Account
    {
        public Saving(string CustomerName,int Balance):base(CustomerName,Balance)
        {
            Console.WriteLine("Saving object");
        }

        public override void Deposite(int Amt)
        {
            Balance = Balance + Amt;
        }

        public override void Withdraw(int Amt)
        {
            Balance = Balance - Amt;
        }
    }
}
