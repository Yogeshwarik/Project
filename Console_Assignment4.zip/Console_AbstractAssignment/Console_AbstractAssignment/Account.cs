﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractAssignment
{
    abstract class Account
    {
        private int AccountID;
        protected string CustomerName;
        protected int Balance;
        private static int Count = 1000;

        public Account(string CustomerName,int Balance)
        {
            this.AccountID = ++Account.Count;
            this.CustomerName = CustomerName;
            this.Balance = Balance;
        }
        public int PAccountID
        {
            get
            {
                return this.AccountID;
            }
        }
        public string PCustomerName
        {
            get
            {
                return this.CustomerName;
            }
        }
        public int PBalance
        {
            get
            {
                return this.Balance;
            }
        }
        public abstract void Deposite(int Amt);
        public abstract void Withdraw(int Amt);
    }
}
