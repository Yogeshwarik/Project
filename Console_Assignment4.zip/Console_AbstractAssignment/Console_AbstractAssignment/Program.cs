﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_AbstractAssignment
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Customer Name");
            string name = Console.ReadLine();

            Console.WriteLine("enter the Balance");
            int balance = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the type of object");
            string type = Console.ReadLine();

            Account obj = null;
            if(type=="Saving")
            {
                obj = new Saving(name, balance);
            }
            else if(type=="Current")
            {
                obj = new Current(name, balance);

            }
            if(obj!=null)
            {
                Console.WriteLine("AccountID:" + obj.PAccountID);
                Console.WriteLine("Customer Name;" + obj.PCustomerName);
                Console.WriteLine("Balance:" + balance);

                Console.WriteLine("enter the Amount to deposit");
                int deposite = Convert.ToInt32(Console.ReadLine());

                obj.Deposite(deposite);
                balance = obj.PBalance;
                Console.WriteLine("deposite amount:" + balance);

                Console.WriteLine("enter the amount to withdraw");
                int amt = Convert.ToInt32(Console.ReadLine());

                obj.Withdraw(amt);
                balance = obj.PBalance;

                Console.WriteLine("Withfdraw amount :" + balance);
                Console.ReadLine();
            }


        }
    }
}
