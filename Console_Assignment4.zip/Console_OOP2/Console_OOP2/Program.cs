﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_OOP2
{
    class Program
    {
        static void Main(string[] args)
        {
            Student obj1 = new Student(1, "ABC");
           
            Console.ReadLine();
        }
    }
}
