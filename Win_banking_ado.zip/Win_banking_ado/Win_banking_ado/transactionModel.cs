﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_banking_ado
{
    class transactionModel
    {
        public int transactionid { get; set; }
        public int accountid { get; set; }
        public string transactiontype { get; set; }
        public int amount { get; set; }
        public DateTime transactiondate { get; set; }

    }
}
