﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Win_banking_ado
{
    public partial class Frm_accountinfo : Form
    {
        public Frm_accountinfo()
        {
            InitializeComponent();
        }

        private void btn_searchcust_Click(object sender, EventArgs e)
        {

            //if (txt_cid.Text == string.Empty)
           // {
               // lbl_accountstatus.Text = "enter the account ID";
            //}
            
            
                bankingDAL dal = new bankingDAL();
                int id1 = bankingDAL.ID;
                  List<accountModel>cutlist = dal.find(id1);
                    dg_account.DataSource = cutlist;
                
      
            
        }
    }
}
