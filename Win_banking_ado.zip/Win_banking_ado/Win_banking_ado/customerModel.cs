﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Win_banking_ado
{
    class customerModel
    {
        public int customerid { get; set; }
        public string customername { get; set; }
        public string customerpassword { get; set; }
        public string customergender { get; set; }
        public string customermobile { get; set; }
        public string customeremail { get; set; }


    }
}
