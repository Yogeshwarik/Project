﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_banking_ado
{
    public partial class Frm_home : Form
    {
        public Frm_home()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Frm_transinfo obj3 = new Frm_transinfo();
            obj3.Show();
        }

        private void btn_newaccount_Click(object sender, EventArgs e)
        {
            Frm_newaccount obj = new Frm_newaccount();
            obj.Show();
        }

        private void btn_accountinfo_Click(object sender, EventArgs e)
        {
            Frm_accountinfo obj1 = new Frm_accountinfo();
            obj1.Show();
        }

        private void btn_newtrans_Click(object sender, EventArgs e)
        {
            Frm_new_transaction obj2 = new Frm_new_transaction();
            obj2.Show();
        }
    }
}
