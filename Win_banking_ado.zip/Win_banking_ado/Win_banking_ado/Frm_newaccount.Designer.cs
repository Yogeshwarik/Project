﻿namespace Win_banking_ado
{
    partial class Frm_newaccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_balance = new System.Windows.Forms.TextBox();
            this.txt_accounttype = new System.Windows.Forms.TextBox();
            this.lbl_balance = new System.Windows.Forms.Label();
            this.lbl_accounttype = new System.Windows.Forms.Label();
            this.lbl_custid = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.dtp_date = new System.Windows.Forms.DateTimePicker();
            this.btn_addaccount = new System.Windows.Forms.Button();
            this.lbl_accid = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txt_balance
            // 
            this.txt_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_balance.Location = new System.Drawing.Point(389, 163);
            this.txt_balance.Name = "txt_balance";
            this.txt_balance.Size = new System.Drawing.Size(122, 29);
            this.txt_balance.TabIndex = 32;
            this.txt_balance.TextChanged += new System.EventHandler(this.txt_custadd_TextChanged);
            // 
            // txt_accounttype
            // 
            this.txt_accounttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_accounttype.Location = new System.Drawing.Point(389, 108);
            this.txt_accounttype.Name = "txt_accounttype";
            this.txt_accounttype.Size = new System.Drawing.Size(122, 29);
            this.txt_accounttype.TabIndex = 31;
            // 
            // lbl_balance
            // 
            this.lbl_balance.AutoSize = true;
            this.lbl_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_balance.Location = new System.Drawing.Point(186, 163);
            this.lbl_balance.Name = "lbl_balance";
            this.lbl_balance.Size = new System.Drawing.Size(153, 24);
            this.lbl_balance.TabIndex = 29;
            this.lbl_balance.Text = "Account Balance";
            // 
            // lbl_accounttype
            // 
            this.lbl_accounttype.AutoSize = true;
            this.lbl_accounttype.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accounttype.Location = new System.Drawing.Point(202, 108);
            this.lbl_accounttype.Name = "lbl_accounttype";
            this.lbl_accounttype.Size = new System.Drawing.Size(128, 24);
            this.lbl_accounttype.TabIndex = 27;
            this.lbl_accounttype.Text = "Account Type";
            // 
            // lbl_custid
            // 
            this.lbl_custid.AutoSize = true;
            this.lbl_custid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_custid.Location = new System.Drawing.Point(199, 66);
            this.lbl_custid.Name = "lbl_custid";
            this.lbl_custid.Size = new System.Drawing.Size(110, 24);
            this.lbl_custid.TabIndex = 26;
            this.lbl_custid.Text = "customer ID";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_date.Location = new System.Drawing.Point(158, 211);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(172, 24);
            this.lbl_date.TabIndex = 33;
            this.lbl_date.Text = "Account open Date";
            // 
            // dtp_date
            // 
            this.dtp_date.CustomFormat = "MM-dd-yyyy";
            this.dtp_date.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_date.Location = new System.Drawing.Point(377, 215);
            this.dtp_date.Name = "dtp_date";
            this.dtp_date.Size = new System.Drawing.Size(200, 20);
            this.dtp_date.TabIndex = 35;
            // 
            // btn_addaccount
            // 
            this.btn_addaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addaccount.Location = new System.Drawing.Point(298, 260);
            this.btn_addaccount.Name = "btn_addaccount";
            this.btn_addaccount.Size = new System.Drawing.Size(134, 39);
            this.btn_addaccount.TabIndex = 36;
            this.btn_addaccount.Text = "Add Account";
            this.btn_addaccount.UseVisualStyleBackColor = true;
            this.btn_addaccount.Click += new System.EventHandler(this.btn_addaccount_Click);
            // 
            // lbl_accid
            // 
            this.lbl_accid.AutoSize = true;
            this.lbl_accid.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accid.Location = new System.Drawing.Point(199, 340);
            this.lbl_accid.Name = "lbl_accid";
            this.lbl_accid.Size = new System.Drawing.Size(131, 20);
            this.lbl_accid.TabIndex = 37;
            this.lbl_accid.Text = "Account Status  :";
            // 
            // Frm_newaccount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSalmon;
            this.ClientSize = new System.Drawing.Size(767, 400);
            this.Controls.Add(this.lbl_accid);
            this.Controls.Add(this.btn_addaccount);
            this.Controls.Add(this.dtp_date);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.txt_balance);
            this.Controls.Add(this.txt_accounttype);
            this.Controls.Add(this.lbl_balance);
            this.Controls.Add(this.lbl_accounttype);
            this.Controls.Add(this.lbl_custid);
            this.Name = "Frm_newaccount";
            this.Text = "Frm_newaccount";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_balance;
        private System.Windows.Forms.TextBox txt_accounttype;
        private System.Windows.Forms.Label lbl_balance;
        private System.Windows.Forms.Label lbl_accounttype;
        private System.Windows.Forms.Label lbl_custid;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.DateTimePicker dtp_date;
        private System.Windows.Forms.Button btn_addaccount;
        private System.Windows.Forms.Label lbl_accid;
    }
}