﻿namespace Win_banking_ado
{
    partial class Frm_home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_newaccount = new System.Windows.Forms.Button();
            this.btn_newtrans = new System.Windows.Forms.Button();
            this.btn_accountinfo = new System.Windows.Forms.Button();
            this.btn_transinfo = new System.Windows.Forms.Button();
            this.lbl_account = new System.Windows.Forms.Label();
            this.lbl_transaction = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_newaccount
            // 
            this.btn_newaccount.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_newaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newaccount.Location = new System.Drawing.Point(69, 167);
            this.btn_newaccount.Name = "btn_newaccount";
            this.btn_newaccount.Size = new System.Drawing.Size(188, 50);
            this.btn_newaccount.TabIndex = 0;
            this.btn_newaccount.Text = "New Account";
            this.btn_newaccount.UseVisualStyleBackColor = false;
            this.btn_newaccount.Click += new System.EventHandler(this.btn_newaccount_Click);
            // 
            // btn_newtrans
            // 
            this.btn_newtrans.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_newtrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_newtrans.Location = new System.Drawing.Point(490, 167);
            this.btn_newtrans.Name = "btn_newtrans";
            this.btn_newtrans.Size = new System.Drawing.Size(230, 50);
            this.btn_newtrans.TabIndex = 1;
            this.btn_newtrans.Text = "New Transaction";
            this.btn_newtrans.UseVisualStyleBackColor = false;
            this.btn_newtrans.Click += new System.EventHandler(this.btn_newtrans_Click);
            // 
            // btn_accountinfo
            // 
            this.btn_accountinfo.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_accountinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_accountinfo.Location = new System.Drawing.Point(50, 290);
            this.btn_accountinfo.Name = "btn_accountinfo";
            this.btn_accountinfo.Size = new System.Drawing.Size(228, 50);
            this.btn_accountinfo.TabIndex = 2;
            this.btn_accountinfo.Text = "My Account Info";
            this.btn_accountinfo.UseVisualStyleBackColor = false;
            this.btn_accountinfo.Click += new System.EventHandler(this.btn_accountinfo_Click);
            // 
            // btn_transinfo
            // 
            this.btn_transinfo.BackColor = System.Drawing.Color.RoyalBlue;
            this.btn_transinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_transinfo.Location = new System.Drawing.Point(479, 290);
            this.btn_transinfo.Name = "btn_transinfo";
            this.btn_transinfo.Size = new System.Drawing.Size(269, 50);
            this.btn_transinfo.TabIndex = 3;
            this.btn_transinfo.Text = "My Transaction Info";
            this.btn_transinfo.UseVisualStyleBackColor = false;
            this.btn_transinfo.Click += new System.EventHandler(this.button4_Click);
            // 
            // lbl_account
            // 
            this.lbl_account.AutoSize = true;
            this.lbl_account.BackColor = System.Drawing.Color.Salmon;
            this.lbl_account.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_account.Location = new System.Drawing.Point(32, 54);
            this.lbl_account.Name = "lbl_account";
            this.lbl_account.Size = new System.Drawing.Size(272, 25);
            this.lbl_account.TabIndex = 4;
            this.lbl_account.Text = "ACCOUNT  INFORMATION";
            // 
            // lbl_transaction
            // 
            this.lbl_transaction.AutoSize = true;
            this.lbl_transaction.BackColor = System.Drawing.Color.Salmon;
            this.lbl_transaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transaction.Location = new System.Drawing.Point(446, 54);
            this.lbl_transaction.Name = "lbl_transaction";
            this.lbl_transaction.Size = new System.Drawing.Size(312, 25);
            this.lbl_transaction.TabIndex = 6;
            this.lbl_transaction.Text = "TRANSACTION INFORMATION";
            // 
            // Frm_home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(802, 429);
            this.Controls.Add(this.lbl_transaction);
            this.Controls.Add(this.lbl_account);
            this.Controls.Add(this.btn_transinfo);
            this.Controls.Add(this.btn_accountinfo);
            this.Controls.Add(this.btn_newtrans);
            this.Controls.Add(this.btn_newaccount);
            this.Name = "Frm_home";
            this.Text = "Frm_home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_newaccount;
        private System.Windows.Forms.Button btn_newtrans;
        private System.Windows.Forms.Button btn_accountinfo;
        private System.Windows.Forms.Button btn_transinfo;
        private System.Windows.Forms.Label lbl_account;
        private System.Windows.Forms.Label lbl_transaction;
    }
}