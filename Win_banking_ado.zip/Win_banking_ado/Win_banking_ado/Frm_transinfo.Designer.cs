﻿namespace Win_banking_ado
{
    partial class Frm_transinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_transtatus = new System.Windows.Forms.Label();
            this.dg_transaction = new System.Windows.Forms.DataGridView();
            this.btn_searchtrans = new System.Windows.Forms.Button();
            this.txt_accid = new System.Windows.Forms.TextBox();
            this.lbl_key = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_transaction)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_transtatus
            // 
            this.lbl_transtatus.AutoSize = true;
            this.lbl_transtatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_transtatus.Location = new System.Drawing.Point(230, 354);
            this.lbl_transtatus.Name = "lbl_transtatus";
            this.lbl_transtatus.Size = new System.Drawing.Size(125, 16);
            this.lbl_transtatus.TabIndex = 28;
            this.lbl_transtatus.Text = "Transaction Status :";
            // 
            // dg_transaction
            // 
            this.dg_transaction.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_transaction.Location = new System.Drawing.Point(144, 136);
            this.dg_transaction.Name = "dg_transaction";
            this.dg_transaction.Size = new System.Drawing.Size(599, 197);
            this.dg_transaction.TabIndex = 27;
            // 
            // btn_searchtrans
            // 
            this.btn_searchtrans.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_searchtrans.Location = new System.Drawing.Point(559, 56);
            this.btn_searchtrans.Name = "btn_searchtrans";
            this.btn_searchtrans.Size = new System.Drawing.Size(167, 60);
            this.btn_searchtrans.TabIndex = 26;
            this.btn_searchtrans.Text = "Search Tranaction Details";
            this.btn_searchtrans.UseVisualStyleBackColor = true;
            this.btn_searchtrans.Click += new System.EventHandler(this.btn_searchtrans_Click);
            // 
            // txt_accid
            // 
            this.txt_accid.BackColor = System.Drawing.Color.Snow;
            this.txt_accid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_accid.Location = new System.Drawing.Point(298, 71);
            this.txt_accid.Name = "txt_accid";
            this.txt_accid.Size = new System.Drawing.Size(125, 29);
            this.txt_accid.TabIndex = 25;
            // 
            // lbl_key
            // 
            this.lbl_key.AutoSize = true;
            this.lbl_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_key.Location = new System.Drawing.Point(109, 76);
            this.lbl_key.Name = "lbl_key";
            this.lbl_key.Size = new System.Drawing.Size(157, 24);
            this.lbl_key.TabIndex = 24;
            this.lbl_key.Text = "Enter Account ID:";
            // 
            // Frm_transinfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(852, 426);
            this.Controls.Add(this.lbl_transtatus);
            this.Controls.Add(this.dg_transaction);
            this.Controls.Add(this.btn_searchtrans);
            this.Controls.Add(this.txt_accid);
            this.Controls.Add(this.lbl_key);
            this.Name = "Frm_transinfo";
            this.Text = "Frm_transinfo";
            ((System.ComponentModel.ISupportInitialize)(this.dg_transaction)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_transtatus;
        private System.Windows.Forms.DataGridView dg_transaction;
        private System.Windows.Forms.Button btn_searchtrans;
        private System.Windows.Forms.TextBox txt_accid;
        private System.Windows.Forms.Label lbl_key;
    }
}