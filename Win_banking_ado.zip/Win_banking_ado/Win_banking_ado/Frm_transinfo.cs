﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_banking_ado
{
    public partial class Frm_transinfo : Form
    {
        public Frm_transinfo()
        {
            InitializeComponent();
        }

        private void btn_searchtrans_Click(object sender, EventArgs e)
        {
            /*if (txt_accid.Text == string.Empty)
            {
                lbl_transtatus.Text = "enter the account ID";
            }*/
            
            
                bankingDAL dal = new bankingDAL();
                int id1 = bankingDAL.AID;
                List<transactionModel> list = dal.search(id1);
                dg_transaction.DataSource = list;

            
        }
    }
}
