﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Win_banking_ado
{
    public partial class Frm_newaccount : Form
    {
        public Frm_newaccount()
        {
            InitializeComponent();
        }

        private void txt_custadd_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_addaccount_Click(object sender, EventArgs e)
        {

           /* if (txt_custid.Text == string.Empty)
            {
                lbl_accid.Text = "enter customerID";
            }*/
             if (txt_accounttype.Text == string.Empty)
            {
                lbl_accid.Text = "enter account type";
            }

            else if (dtp_date.Text == string.Empty)
            {
                lbl_accid.Text = "select the date";
            }

           else
            {
                accountModel model1 = new accountModel();
                model1.customerID = bankingDAL.ID;
                model1.accounttype = Convert.ToString(txt_accounttype.Text);
                model1.accountbalance= Convert.ToInt32(txt_balance.Text);
                model1.accountdate = Convert.ToDateTime(dtp_date.Value);

                bankingDAL dal = new bankingDAL();
                int id1 = dal.addaccount(model1);
                lbl_accid.Text = "account added,ID" + id1;
            }


        }
    
    }
}
