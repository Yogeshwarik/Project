﻿namespace Win_banking_ado
{
    partial class Frm_accountinfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dg_account = new System.Windows.Forms.DataGridView();
            this.btn_searchcust = new System.Windows.Forms.Button();
            this.txt_cid = new System.Windows.Forms.TextBox();
            this.lbl_key = new System.Windows.Forms.Label();
            this.lbl_accountstatus = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dg_account)).BeginInit();
            this.SuspendLayout();
            // 
            // dg_account
            // 
            this.dg_account.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dg_account.Location = new System.Drawing.Point(143, 139);
            this.dg_account.Name = "dg_account";
            this.dg_account.Size = new System.Drawing.Size(599, 197);
            this.dg_account.TabIndex = 22;
            // 
            // btn_searchcust
            // 
            this.btn_searchcust.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_searchcust.Location = new System.Drawing.Point(558, 59);
            this.btn_searchcust.Name = "btn_searchcust";
            this.btn_searchcust.Size = new System.Drawing.Size(167, 60);
            this.btn_searchcust.TabIndex = 21;
            this.btn_searchcust.Text = "Search Customer Account Details";
            this.btn_searchcust.UseVisualStyleBackColor = true;
            this.btn_searchcust.Click += new System.EventHandler(this.btn_searchcust_Click);
            // 
            // txt_cid
            // 
            this.txt_cid.BackColor = System.Drawing.Color.Snow;
            this.txt_cid.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cid.Location = new System.Drawing.Point(297, 74);
            this.txt_cid.Name = "txt_cid";
            this.txt_cid.Size = new System.Drawing.Size(125, 29);
            this.txt_cid.TabIndex = 20;
            // 
            // lbl_key
            // 
            this.lbl_key.AutoSize = true;
            this.lbl_key.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_key.Location = new System.Drawing.Point(108, 79);
            this.lbl_key.Name = "lbl_key";
            this.lbl_key.Size = new System.Drawing.Size(168, 24);
            this.lbl_key.TabIndex = 19;
            this.lbl_key.Text = "Enter Customer ID:";
            // 
            // lbl_accountstatus
            // 
            this.lbl_accountstatus.AutoSize = true;
            this.lbl_accountstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_accountstatus.Location = new System.Drawing.Point(229, 357);
            this.lbl_accountstatus.Name = "lbl_accountstatus";
            this.lbl_accountstatus.Size = new System.Drawing.Size(101, 16);
            this.lbl_accountstatus.TabIndex = 23;
            this.lbl_accountstatus.Text = "account Status :";
            // 
            // Frm_accountinfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(884, 395);
            this.Controls.Add(this.lbl_accountstatus);
            this.Controls.Add(this.dg_account);
            this.Controls.Add(this.btn_searchcust);
            this.Controls.Add(this.txt_cid);
            this.Controls.Add(this.lbl_key);
            this.Name = "Frm_accountinfo";
            this.Text = "Frm_accountinfo";
            ((System.ComponentModel.ISupportInitialize)(this.dg_account)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dg_account;
        private System.Windows.Forms.Button btn_searchcust;
        private System.Windows.Forms.TextBox txt_cid;
        private System.Windows.Forms.Label lbl_key;
        private System.Windows.Forms.Label lbl_accountstatus;
    }
}